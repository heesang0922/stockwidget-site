# StockWidget

Windows 바탕화면에서 관심 종목을 검색하고 확인하는 PowerShell 5.1 및 WPF 앱입니다. 한국어 화면에는 Windows 기본 글꼴인 맑은 고딕을 사용합니다.

## 기능

- 네이버 금융에서 종목명 또는 티커/코드로 검색하고 검색 결과를 관심 종목에 추가
- 목록에서 관심 종목 삭제 및 `StockWidget.settings.json`에 목록 저장
- 검색 연결 오류와 결과 없음 상태 표시
- 종목별·묶음 위젯, 시세 표시, 테마 및 표시 설정

## 실행 방법

Windows에서 아래 중 하나로 실행할 수 있습니다.

- `StockWidget.exe`: Windows 런처를 통한 실행
- `StockWidget.cmd`: PowerShell 스크립트 직접 실행
- PowerShell 5.1에서 프로젝트 폴더로 이동한 뒤:

```powershell
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File .\StockWidget.ps1
```

런처 또는 스크립트는 프로젝트 파일과 같은 폴더에서 실행해야 합니다. 네이버 금융 종목 검색에는 인터넷 연결이 필요합니다.

## 런처 빌드

Windows PowerShell에서 프로젝트 폴더를 연 뒤 .NET Framework C# 컴파일러로 빌드합니다. `StockWidget.ico`가 있으면 런처 아이콘에도 적용됩니다.

```powershell
$csc = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
& $csc /nologo /target:winexe /win32icon:StockWidget.ico /out:StockWidget.exe /reference:System.dll /reference:System.Windows.Forms.dll .\StockWidgetLauncher.cs
```

아이콘 파일이 없는 환경에서는 `/win32icon:StockWidget.ico` 옵션을 빼고 빌드할 수 있습니다. 빌드된 런처와 함께 `StockWidget.ps1`, `StockDiscovery.ps1`, `StockQuotes.ps1` 및 필요한 아이콘 파일을 같은 폴더에 둡니다.

## 설정 파일

관심 종목은 앱 실행 폴더의 `StockWidget.settings.json`에 저장됩니다. 새로 시작하려면 빈 목록 예시인 `StockWidget.settings.example.json`의 `[]`를 참고하세요. 앱 설정 파일과 인증 정보 파일은 개인 데이터이므로 Git에 포함하지 않습니다. `.gitignore`는 개인 설정 파일과 빌드 결과를 제외합니다.
