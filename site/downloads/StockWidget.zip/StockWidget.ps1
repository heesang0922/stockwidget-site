﻿param([switch]$Check)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class StockWidgetTaskbarIdentity {
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    public static extern int SetCurrentProcessExplicitAppUserModelID(string appID);
}
'@
[void][StockWidgetTaskbarIdentity]::SetCurrentProcessExplicitAppUserModelID('StockWidget.Desktop')
trap { try { [Windows.MessageBox]::Show($_.Exception.ToString(), 'StockWidget 오류', 'OK', 'Error') | Out-Null } catch {}; break }
function WindowFrom($xaml) {
    [Windows.Markup.XamlReader]::Parse([string]$xaml)
}
$window=WindowFrom @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="주가 위젯" Width="1360" Height="760" MinWidth="1120" MinHeight="700" WindowStartupLocation="CenterScreen" UseLayoutRounding="True" Background="{DynamicResource WindowBgBrush}" FontFamily="Malgun Gothic" Foreground="{DynamicResource TextPrimaryBrush}">
<Window.Resources>
<SolidColorBrush x:Key="WindowBgBrush" Color="#FF111315"/>
<SolidColorBrush x:Key="CardBgBrush" Color="#FF1B1E22"/>
<SolidColorBrush x:Key="SubCardBgBrush" Color="#FF21252C"/>
<SolidColorBrush x:Key="IndexBarBgBrush" Color="#FF17191C"/>
<SolidColorBrush x:Key="BorderLineBrush" Color="#FF2D3138"/>
<SolidColorBrush x:Key="TextPrimaryBrush" Color="#FFF2F4F7"/>
<SolidColorBrush x:Key="TextSecondaryBrush" Color="#FF9299A1"/>
<SolidColorBrush x:Key="InputBgBrush" Color="#FF14161A"/>
<SolidColorBrush x:Key="ButtonBgBrush" Color="#FF282C33"/>
<SolidColorBrush x:Key="ButtonFgBrush" Color="#FFE8ECF1"/>
<SolidColorBrush x:Key="ScrollThumbBrush" Color="#FF76818E"/>
<SolidColorBrush x:Key="RowHoverBrush" Color="#FF252A33"/>
<SolidColorBrush x:Key="IndexCardBrush" Color="#FF21252C"/>
<SolidColorBrush x:Key="AddedSurfaceBrush" Color="#FF262A32"/>
<SolidColorBrush x:Key="{x:Static SystemColors.HighlightBrushKey}" Color="#FF1B1E22"/>
<SolidColorBrush x:Key="{x:Static SystemColors.InactiveSelectionHighlightBrushKey}" Color="#FF1B1E22"/>
<SolidColorBrush x:Key="{x:Static SystemColors.HighlightTextBrushKey}" Color="#FFF2F4F7"/>
<SolidColorBrush x:Key="{x:Static SystemColors.InactiveSelectionHighlightTextBrushKey}" Color="#FFF2F4F7"/>
<Style TargetType="Button"><Setter Property="Cursor" Value="Hand"/><Setter Property="Background" Value="{DynamicResource ButtonBgBrush}"/><Setter Property="Foreground" Value="{DynamicResource ButtonFgBrush}"/><Setter Property="MinHeight" Value="32"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="surface" CornerRadius="9" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="surface" Property="Opacity" Value=".84"/></Trigger><Trigger Property="IsPressed" Value="True"><Setter TargetName="surface" Property="Opacity" Value=".68"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
<Style TargetType="ToggleButton"><Setter Property="Cursor" Value="Hand"/><Setter Property="Background" Value="{DynamicResource SubCardBgBrush}"/><Setter Property="Foreground" Value="{DynamicResource TextSecondaryBrush}"/><Setter Property="Padding" Value="10,7"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ToggleButton"><Border x:Name="toggleSurface" Background="{TemplateBinding Background}" CornerRadius="12" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsChecked" Value="True"><Setter TargetName="toggleSurface" Property="Background" Value="#2F80FF"/><Setter Property="Foreground" Value="#FFFFFFFF"/></Trigger><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="toggleSurface" Property="Opacity" Value=".85"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
<Style TargetType="ComboBox"><Setter Property="Foreground" Value="{DynamicResource TextPrimaryBrush}"/><Setter Property="Background" Value="{DynamicResource ButtonBgBrush}"/><Setter Property="BorderThickness" Value="0"/><Setter Property="Padding" Value="0"/><Setter Property="FontSize" Value="13"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ComboBox"><Grid><ToggleButton x:Name="Toggle" Focusable="False" IsChecked="{Binding IsDropDownOpen,Mode=TwoWay,RelativeSource={RelativeSource TemplatedParent}}" Background="{TemplateBinding Background}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1"><ToggleButton.Template><ControlTemplate TargetType="ToggleButton"><Border x:Name="Box" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="10" Padding="11,7"><Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="18"/></Grid.ColumnDefinitions><ContentPresenter Content="{Binding SelectionBoxItem,RelativeSource={RelativeSource AncestorType=ComboBox}}" ContentTemplate="{Binding SelectionBoxItemTemplate,RelativeSource={RelativeSource AncestorType=ComboBox}}" VerticalAlignment="Center"/><Path Grid.Column="1" Data="M 1 3 L 5 7 L 9 3" Stroke="{DynamicResource TextSecondaryBrush}" StrokeThickness="1.7" HorizontalAlignment="Center" VerticalAlignment="Center"/></Grid></Border></ControlTemplate></ToggleButton.Template></ToggleButton><Popup x:Name="Popup" Placement="Bottom" IsOpen="{TemplateBinding IsDropDownOpen}" AllowsTransparency="True" Focusable="False" PopupAnimation="Fade"><Border Background="{DynamicResource CardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="11" Padding="4" MinWidth="{Binding ActualWidth,RelativeSource={RelativeSource TemplatedParent}}"><ScrollViewer><ItemsPresenter/></ScrollViewer></Border></Popup></Grid></ControlTemplate></Setter.Value></Setter><Setter Property="ItemContainerStyle"><Setter.Value><Style TargetType="ComboBoxItem"><Setter Property="Padding" Value="11,8"/><Setter Property="Foreground" Value="{DynamicResource TextPrimaryBrush}"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ComboBoxItem"><Border x:Name="item" Background="Transparent" CornerRadius="7" Padding="{TemplateBinding Padding}"><ContentPresenter TextElement.Foreground="{TemplateBinding Foreground}"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="item" Property="Background" Value="{DynamicResource RowHoverBrush}"/></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="item" Property="Background" Value="#262F80FF"/><Setter Property="Foreground" Value="#3A9BFF"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style></Setter.Value></Setter></Style>
<Style TargetType="DataGrid"><Setter Property="Background" Value="Transparent"/><Setter Property="Foreground" Value="{DynamicResource TextPrimaryBrush}"/><Setter Property="RowBackground" Value="Transparent"/><Setter Property="AlternatingRowBackground" Value="Transparent"/><Setter Property="BorderThickness" Value="0"/><Setter Property="GridLinesVisibility" Value="Horizontal"/><Setter Property="HorizontalGridLinesBrush" Value="{DynamicResource BorderLineBrush}"/><Setter Property="VerticalContentAlignment" Value="Center"/></Style>
<Style TargetType="ScrollBar"><Setter Property="Width" Value="8"/><Setter Property="Height" Value="8"/><Setter Property="Background" Value="Transparent"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ScrollBar"><Track x:Name="PART_Track" Orientation="{TemplateBinding Orientation}" Minimum="{TemplateBinding Minimum}" Maximum="{TemplateBinding Maximum}" ViewportSize="{TemplateBinding ViewportSize}" Value="{TemplateBinding Value}" IsDirectionReversed="False"><Track.Thumb><Thumb><Thumb.Template><ControlTemplate TargetType="Thumb"><Border x:Name="thumbSurface" Background="{DynamicResource ScrollThumbBrush}" CornerRadius="4" Margin="2"/><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="thumbSurface" Property="Opacity" Value=".72"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Thumb.Template></Thumb></Track.Thumb></Track><ControlTemplate.Triggers><Trigger Property="Orientation" Value="Horizontal"><Setter Property="Height" Value="8"/><Setter Property="Width" Value="Auto"/></Trigger><Trigger Property="Orientation" Value="Vertical"><Setter Property="Width" Value="8"/><Setter Property="Height" Value="Auto"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
<Style TargetType="DataGridCell"><Setter Property="Padding" Value="5,2"/><Setter Property="BorderThickness" Value="0"/><Setter Property="Background" Value="Transparent"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="DataGridCell"><Border Padding="{TemplateBinding Padding}" Background="{TemplateBinding Background}"><ContentPresenter VerticalAlignment="Center"/></Border></ControlTemplate></Setter.Value></Setter></Style>
<Style TargetType="DataGridRow"><Setter Property="BorderThickness" Value="0"/><Setter Property="Background" Value="Transparent"/><Setter Property="SnapsToDevicePixels" Value="True"/><Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="{DynamicResource RowHoverBrush}"/></Trigger></Style.Triggers></Style>
</Window.Resources><DockPanel Margin="22">
<DockPanel DockPanel.Dock="Top" Margin="0,0,0,14"><Button Name="settingsButton" DockPanel.Dock="Right" Padding="13,6">⚙ 설정</Button><TextBlock FontSize="23" FontWeight="Bold" Foreground="{DynamicResource TextPrimaryBrush}" VerticalAlignment="Center">내 주식</TextBlock></DockPanel>
<Border Name="indexSurface" DockPanel.Dock="Bottom" CornerRadius="14" Background="{DynamicResource IndexBarBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" Padding="10,8" Margin="0,10,0,0"><DockPanel LastChildFill="True"><StackPanel DockPanel.Dock="Left" Orientation="Horizontal" VerticalAlignment="Center" Margin="0,0,10,0"><Button Name="indexPrev" Padding="9,4" Margin="0,0,5,0" ToolTip="이전 지수">▲</Button><Button Name="indexNext" Padding="9,4" Margin="0,0,8,0" ToolTip="다음 지수">▼</Button><TextBlock Name="indexPageLabel" FontSize="11" Foreground="{DynamicResource TextSecondaryBrush}" VerticalAlignment="Center" Margin="0,0,2,0"/></StackPanel><ItemsControl Name="indexTicker" VerticalAlignment="Center"><ItemsControl.ItemsPanel><ItemsPanelTemplate><UniformGrid Columns="4"/></ItemsPanelTemplate></ItemsControl.ItemsPanel><ItemsControl.ItemTemplate><DataTemplate><Border Background="{DynamicResource IndexCardBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="10" Padding="11,8" Margin="4"><StackPanel><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="{Binding Name}" FontSize="14" FontWeight="SemiBold" Foreground="{DynamicResource TextPrimaryBrush}" TextWrapping="Wrap"/><Border Grid.Column="1" Background="{Binding MarketSurface}" BorderBrush="{Binding MarketBrush}" BorderThickness="1" CornerRadius="8" Padding="6,2" Margin="5,0,0,0" HorizontalAlignment="Right"><TextBlock Text="{Binding MarketStatus}" FontSize="10" FontWeight="SemiBold" Foreground="{Binding MarketBrush}"/></Border></Grid><Grid Margin="0,6,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="{Binding Price}" FontSize="17" FontWeight="Bold" Foreground="{DynamicResource TextPrimaryBrush}" TextWrapping="Wrap"/><TextBlock Grid.Column="1" Text="{Binding Delta}" FontSize="13" Foreground="{Binding DayBrush}" FontWeight="SemiBold" Margin="8,2,0,0" TextWrapping="Wrap" TextAlignment="Right"/></Grid></StackPanel></Border></DataTemplate></ItemsControl.ItemTemplate></ItemsControl></DockPanel></Border>
<Grid><Grid.ColumnDefinitions><ColumnDefinition Width="6.5*"/><ColumnDefinition Width="3.5*"/></Grid.ColumnDefinitions>
<Border Name="stocksSurface" Margin="0,0,7,0" CornerRadius="18" Background="{DynamicResource CardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" Padding="18"><DockPanel Name="dropZone" AllowDrop="True" Background="Transparent" Margin="0,2">
<Border Name="apiBanner" DockPanel.Dock="Top" Background="#29251B" BorderBrush="#6D5018" BorderThickness="1" CornerRadius="14" Padding="14,10" Margin="0,0,0,12"><DockPanel><WrapPanel DockPanel.Dock="Right" VerticalAlignment="Center"><Button Name="checkSettings" Padding="10,5" Margin="4,0">설정에서 확인</Button><Button Name="retryApi" Padding="10,5">재연결 시도</Button></WrapPanel><TextBlock Name="tossStatus" Foreground="#FFC94A" FontSize="14" TextWrapping="Wrap" VerticalAlignment="Center">● 토스 연결 상태를 확인하고 있어요.</TextBlock></DockPanel></Border>
<DockPanel DockPanel.Dock="Top" Margin="0,0,0,11"><WrapPanel DockPanel.Dock="Left"><ToggleButton Name="filterAll" IsChecked="True" Content="전체 0" Padding="14,8" Margin="0,0,5,0"/><ToggleButton Name="filterWidgets" Content="위젯 표시 중 0" Padding="14,8" Margin="0,0,5,0"/><ToggleButton Name="filterHoldings" Content="보유 주식 0" Padding="14,8"/></WrapPanel><StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center"><TextBlock Foreground="#20B486" FontWeight="SemiBold" Margin="7,0">● 정규장</TextBlock><TextBlock Foreground="#F0A542" FontWeight="SemiBold" Margin="7,0">● 프리마켓</TextBlock><TextBlock Foreground="#8585FF" FontWeight="SemiBold" Margin="7,0">● 애프터</TextBlock><TextBlock Foreground="{DynamicResource TextSecondaryBrush}" Margin="7,0">● 장마감</TextBlock></StackPanel></DockPanel>
<DockPanel DockPanel.Dock="Top" Margin="0,0,0,7"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="1.7*" MinWidth="112"/><ColumnDefinition Width="5*" MinWidth="150"/><ColumnDefinition Width="2.5*" MinWidth="120"/><ColumnDefinition Width="1.8*" MinWidth="100"/><ColumnDefinition Width="0.6*" MinWidth="42"/></Grid.ColumnDefinitions><TextBlock Text="위젯 표시" Foreground="{DynamicResource TextSecondaryBrush}" Margin="12,0"/><TextBlock Grid.Column="1" Text="종목명 · 장 상태" Foreground="{DynamicResource TextSecondaryBrush}"/><TextBlock Grid.Column="2" Text="현재가 / 당일 등락" TextAlignment="Right" Foreground="{DynamicResource TextSecondaryBrush}"/><TextBlock Grid.Column="3" Text="보유 수익률" TextAlignment="Right" Foreground="{DynamicResource TextSecondaryBrush}"/></Grid></DockPanel>
<StackPanel DockPanel.Dock="Bottom" Margin="0,10,0,0"><Border BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="0,1,0,0" Padding="0,12,0,0"><DockPanel LastChildFill="True"><WrapPanel DockPanel.Dock="Left"><Button Name="group" Padding="14,8" Background="#2F80FF" Foreground="White" FontWeight="SemiBold" ToolTip="위젯 표시가 켜진 종목을 한 위젯에 묶어 표시합니다.">▦  묶어 띄우기</Button><Button Name="pop" Padding="12,8" Margin="6,0,0,0">종목별 위젯</Button><Button Name="update" Padding="11,8" Margin="6,0">⟳ 새로고침</Button></WrapPanel><TextBlock Name="status" DockPanel.Dock="Right" Width="300" Text="지수·환율 60초 · 보유 주식 60초 갱신" Foreground="{DynamicResource TextSecondaryBrush}" VerticalAlignment="Center" TextAlignment="Right" TextWrapping="Wrap" Margin="10,0,0,0"/></DockPanel></Border></StackPanel>
<DataGrid Name="grid" AutoGenerateColumns="False" IsReadOnly="True" SelectionMode="Extended" HeadersVisibility="None" CanUserAddRows="False" MinRowHeight="78" GridLinesVisibility="Horizontal" HorizontalGridLinesBrush="{DynamicResource BorderLineBrush}" HorizontalScrollBarVisibility="Disabled" Background="Transparent" RowBackground="Transparent" AlternatingRowBackground="Transparent"><DataGrid.Columns>
<DataGridTemplateColumn Width="1.7*" MinWidth="112"><DataGridTemplateColumn.CellTemplate><DataTemplate><StackPanel Orientation="Horizontal" VerticalAlignment="Center" Margin="7,0"><ToggleButton Name="widgetToggle" IsChecked="{Binding WidgetVisible,Mode=TwoWay,UpdateSourceTrigger=PropertyChanged}" Width="54" Height="30" Background="#353A43" BorderThickness="0"><ToggleButton.Template><ControlTemplate TargetType="ToggleButton"><Grid Width="54" Height="30"><Border x:Name="Track" Background="#353A43" CornerRadius="15"/><Ellipse x:Name="Thumb" Width="24" Height="24" Fill="White" HorizontalAlignment="Left" Margin="3"/></Grid><ControlTemplate.Triggers><Trigger Property="IsChecked" Value="True"><Setter TargetName="Track" Property="Background" Value="#2D7FF9"/><Setter TargetName="Thumb" Property="HorizontalAlignment" Value="Right"/></Trigger></ControlTemplate.Triggers></ControlTemplate></ToggleButton.Template></ToggleButton><TextBlock Text="{Binding WidgetLabel}" Foreground="{Binding WidgetBrush}" FontSize="12" FontWeight="SemiBold" Width="32" TextAlignment="Left" Margin="9,0,0,0" VerticalAlignment="Center"/></StackPanel></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
<DataGridTemplateColumn Width="5*" MinWidth="150"><DataGridTemplateColumn.CellTemplate><DataTemplate><StackPanel VerticalAlignment="Center"><WrapPanel VerticalAlignment="Center"><TextBlock Text="{Binding DisplayName}" FontSize="16" FontWeight="Bold" Foreground="{DynamicResource TextPrimaryBrush}" TextWrapping="Wrap"/><Button Name="editHoldingBadge" Content="{Binding ModeLabel}" ToolTip="클릭하여 수동 보유(평단가·수량) 설정" IsEnabled="{Binding CanEditHolding}" Background="{Binding ModeBadgeSurface}" Foreground="{Binding ModeBadgeBrush}" BorderBrush="{Binding ModeBadgeBorder}" BorderThickness="1" MinHeight="22" Padding="8,2" Margin="8,0,0,0" FontSize="10" FontWeight="Bold"/></WrapPanel><WrapPanel Margin="0,5,0,0"><TextBlock Text="{Binding Symbol}" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11"/><TextBlock Text="{Binding StatusLine}" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11" Margin="8,3,0,0" Visibility="{Binding ClosedStatusVisibility}"/><Border Background="{Binding StatusSurface}" BorderBrush="{Binding MarketBrush}" BorderThickness="1" CornerRadius="7" Padding="7,2" Margin="8,0,0,0" Visibility="{Binding BadgeStatusVisibility}"><TextBlock Text="{Binding StatusLine}" Foreground="{Binding MarketBrush}" FontSize="11" FontWeight="SemiBold" TextWrapping="Wrap"/></Border></WrapPanel></StackPanel></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
<DataGridTemplateColumn Width="2.5*" MinWidth="120"><DataGridTemplateColumn.CellTemplate><DataTemplate><StackPanel HorizontalAlignment="Right" VerticalAlignment="Center"><TextBlock Text="{Binding Price}" Foreground="{DynamicResource TextPrimaryBrush}" FontSize="17" FontWeight="Bold" TextAlignment="Right" TextWrapping="Wrap"/><TextBlock Text="{Binding Delta}" Foreground="{Binding DayBrush}" FontSize="13" FontWeight="SemiBold" TextAlignment="Right" TextWrapping="Wrap" Margin="0,4,0,0"/></StackPanel></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
<DataGridTemplateColumn Width="1.8*" MinWidth="100"><DataGridTemplateColumn.CellTemplate><DataTemplate><Button Name="editHoldingGain" Background="Transparent" Foreground="{Binding GainBrush}" BorderThickness="0" Padding="4,2" HorizontalContentAlignment="Right" ToolTip="클릭하여 수동 보유(평단가·수량) 설정" IsEnabled="{Binding CanEditHolding}"><StackPanel HorizontalAlignment="Right" VerticalAlignment="Center"><TextBlock Text="{Binding GainDisplay}" Foreground="{Binding GainBrush}" FontSize="14" FontWeight="Bold" TextAlignment="Right" TextWrapping="Wrap"/><TextBlock Text="{Binding GainPnl}" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11" TextAlignment="Right" Margin="0,4,0,0"/></StackPanel></Button></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
<DataGridTemplateColumn Width="0.6*" MinWidth="42"><DataGridTemplateColumn.CellTemplate><DataTemplate><Button Name="rowRemove" Content="×" Width="30" Height="30" Padding="0" FontSize="19" BorderThickness="0" ToolTip="목록에서 제거"><Button.Style><Style TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Visibility" Value="Collapsed"/><Setter Property="Background" Value="Transparent"/><Setter Property="Foreground" Value="#8B949E"/><Style.Triggers><DataTrigger Binding="{Binding RelativeSource={RelativeSource AncestorType=DataGridRow},Path=IsMouseOver}" Value="True"><Setter Property="Visibility" Value="Visible"/></DataTrigger><Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="#F04452"/></Trigger><DataTrigger Binding="{Binding CanDelete}" Value="False"><Setter Property="Visibility" Value="Collapsed"/></DataTrigger></Style.Triggers></Style></Button.Style></Button></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
</DataGrid.Columns></DataGrid></DockPanel></Border>
<Border Name="tossSurface" Visibility="Collapsed"><DataGrid Name="tossGrid"/></Border><Border Name="searchSurface" Grid.Column="1" Margin="7,0,0,0" CornerRadius="18" Background="{DynamicResource CardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" Padding="16"><DockPanel><DockPanel DockPanel.Dock="Top" Margin="0,4,0,12"><ComboBox Name="market" DockPanel.Dock="Right" Width="112" SelectedIndex="0"><ComboBoxItem>코스피</ComboBoxItem><ComboBoxItem>코스닥</ComboBoxItem><ComboBoxItem>미국</ComboBoxItem></ComboBox><TextBlock FontSize="18" FontWeight="Bold" Foreground="{DynamicResource TextPrimaryBrush}" VerticalAlignment="Center">종목 검색</TextBlock></DockPanel>
<Border Name="searchInputSurface" DockPanel.Dock="Top" BorderThickness="1" BorderBrush="{DynamicResource BorderLineBrush}" Background="{DynamicResource InputBgBrush}" CornerRadius="14" Padding="12,9" Margin="0,0,0,8"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="22"/><ColumnDefinition Width="*"/><ColumnDefinition Width="32"/></Grid.ColumnDefinitions><TextBlock Text="&#xE721;" FontFamily="Segoe MDL2 Assets" FontSize="17" Foreground="{DynamicResource TextSecondaryBrush}" VerticalAlignment="Center"/><Grid Grid.Column="1" VerticalAlignment="Center"><TextBox Name="symbol" BorderThickness="0" Background="Transparent" Foreground="{DynamicResource TextPrimaryBrush}" Padding="3,3" MinHeight="34" VerticalContentAlignment="Center" FontSize="14" ToolTip="종목명 또는 코드"/><TextBlock Name="searchPlaceholder" Text="종목명이나 코드 검색" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="14" Margin="4,0" IsHitTestVisible="False" VerticalAlignment="Center"/></Grid><Border Name="searchKeySurface" Grid.Column="2" Background="{DynamicResource SubCardBgBrush}" CornerRadius="6" Padding="4,2" VerticalAlignment="Center"><TextBlock Text="/" FontSize="13" Foreground="{DynamicResource TextSecondaryBrush}" HorizontalAlignment="Center"/></Border></Grid></Border>
<DockPanel DockPanel.Dock="Top" Margin="2,7,2,9" LastChildFill="True"><TextBlock Text="현재가 · 거래량" DockPanel.Dock="Right" Foreground="{DynamicResource TextSecondaryBrush}" VerticalAlignment="Center"/><TextBlock Name="caption" Foreground="{DynamicResource TextSecondaryBrush}" VerticalAlignment="Center" TextWrapping="Wrap"/></DockPanel>
<DataGrid Name="results" AutoGenerateColumns="False" IsReadOnly="True" CanUserAddRows="False" SelectionMode="Single" HeadersVisibility="None" MinRowHeight="66" Background="Transparent" RowBackground="Transparent" AlternatingRowBackground="Transparent" HorizontalScrollBarVisibility="Disabled"><DataGrid.Columns><DataGridTextColumn Header="#" Binding="{Binding Rank}" Width="0.45*" MinWidth="24"><DataGridTextColumn.ElementStyle><Style TargetType="TextBlock"><Setter Property="Foreground" Value="{DynamicResource TextSecondaryBrush}"/><Setter Property="VerticalAlignment" Value="Center"/></Style></DataGridTextColumn.ElementStyle></DataGridTextColumn><DataGridTemplateColumn Width="2.7*" MinWidth="80"><DataGridTemplateColumn.CellTemplate><DataTemplate><StackPanel VerticalAlignment="Center"><TextBlock Text="{Binding Name}" Foreground="{DynamicResource TextPrimaryBrush}" FontWeight="SemiBold" TextWrapping="Wrap"/><TextBlock Text="{Binding SubLine}" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11" TextWrapping="Wrap" Margin="0,3,0,0"/></StackPanel></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn><DataGridTextColumn Header="현재가" Binding="{Binding Price}" Width="1.8*" MinWidth="70"><DataGridTextColumn.ElementStyle><Style TargetType="TextBlock"><Setter Property="Foreground" Value="{DynamicResource TextPrimaryBrush}"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="TextWrapping" Value="Wrap"/><Setter Property="TextAlignment" Value="Right"/><Setter Property="VerticalAlignment" Value="Center"/></Style></DataGridTextColumn.ElementStyle></DataGridTextColumn><DataGridTemplateColumn Width="1.35*" MinWidth="74"><DataGridTemplateColumn.CellTemplate><DataTemplate><Button Name="resultAdd" Padding="8,6" BorderThickness="1" ToolTip="관심 종목에 추가"><Button.Style><Style TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Content" Value="+ 추가"/><Setter Property="Visibility" Value="Visible"/><Setter Property="Background" Value="#1E3A63"/><Setter Property="Foreground" Value="#54A8FF"/><Setter Property="BorderBrush" Value="#2D5A96"/><Style.Triggers><DataTrigger Binding="{Binding IsAdded}" Value="True"><Setter Property="Content" Value="추가됨 ✓"/><Setter Property="IsEnabled" Value="False"/><Setter Property="Background" Value="{DynamicResource AddedSurfaceBrush}"/><Setter Property="Foreground" Value="{DynamicResource TextSecondaryBrush}"/><Setter Property="BorderBrush" Value="{DynamicResource BorderLineBrush}"/></DataTrigger></Style.Triggers></Style></Button.Style></Button></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn></DataGrid.Columns></DataGrid></DockPanel></Border></Grid></DockPanel></Window>
"@
$workArea=[Windows.SystemParameters]::WorkArea;$window.Width=[math]::Max(1120,$workArea.Width*0.88);$window.Height=[math]::Max(700,$workArea.Height*0.80);$window.WindowStartupLocation='CenterScreen';$window.UseLayoutRounding=$true
foreach($name in 'settingsButton','checkSettings','retryApi','apiBanner','filterAll','filterWidgets','filterHoldings','market','symbol','searchPlaceholder','searchInputSurface','searchKeySurface','pop','group','update','grid','tossGrid','tossStatus','status','results','caption','dropZone','indexTicker','indexPageLabel','indexPrev','indexNext'){Set-Variable $name $window.FindName($name)}
$themePath=Join-Path $PSScriptRoot 'StockWidget.theme'
$legacyThemePath=Join-Path $PSScriptRoot 'StockWidget.theme.txt'
if(!(Test-Path $themePath) -and (Test-Path $legacyThemePath)){Copy-Item -LiteralPath $legacyThemePath -Destination $themePath}
$preferencePath=Join-Path $PSScriptRoot 'StockWidget.preferences.json'

$script:alwaysTop=$true
$script:widgetVisibility=@{};$script:hiddenRows=@()
$script:deletedIds=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
if(Test-Path $preferencePath){try{$prefs=Get-Content -Raw $preferencePath | ConvertFrom-Json;if($null -ne $prefs.AlwaysOnTop){$script:alwaysTop=[bool]$prefs.AlwaysOnTop};if($prefs.WidgetVisibility){foreach($prop in $prefs.WidgetVisibility.PSObject.Properties){$script:widgetVisibility[$prop.Name]=[bool]$prop.Value}};if($prefs.HiddenRows){$script:hiddenRows=@($prefs.HiddenRows)}}catch{}}
function Save-Preferences { [IO.File]::WriteAllText($preferencePath,(ConvertTo-Json @{AlwaysOnTop=$script:alwaysTop;WidgetVisibility=$script:widgetVisibility;HiddenRows=$script:hiddenRows}),[Text.UTF8Encoding]::new($true)) }
$script:tableRows=@()
$script:tableFilter='all'
$group.Content='묶어 띄우기 · 0개'
$script:themeDark=if(Test-Path $themePath){(Get-Content -Raw $themePath).Trim() -eq 'dark'}else{$true}
function Add-VisualNodes($node,$list){
    if($null -eq $node){return}
    if($node -is [Windows.Media.Visual] -or $node -is [Windows.Media.Media3D.Visual3D]){
        [void]$list.Add($node)
        $count=[Windows.Media.VisualTreeHelper]::GetChildrenCount($node)
        for($i=0;$i -lt $count;$i++){Add-VisualNodes ([Windows.Media.VisualTreeHelper]::GetChild($node,$i)) $list}
    }
}
function New-Brush($hex){[Windows.Media.BrushConverter]::new().ConvertFromString($hex)}
function New-AppIcon {
    $iconPath=Join-Path $PSScriptRoot 'StockWidget.ico'
    if(Test-Path $iconPath){
        $decoder=[Windows.Media.Imaging.BitmapDecoder]::Create([uri]$iconPath,[Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat,[Windows.Media.Imaging.BitmapCacheOption]::OnLoad)
        $frame=$decoder.Frames[0];$frame.Freeze();return $frame
    }
    $visual=[Windows.Media.DrawingVisual]::new();$context=$visual.RenderOpen()
    $context.DrawRoundedRectangle((New-Brush '#FF2F80FF'),$null,[Windows.Rect]::new(1,1,30,30),7,7)
    $geometry=[Windows.Media.Geometry]::Parse('M 6,22 L 12,16 L 16,19 L 24,9')
    $context.DrawGeometry($null,[Windows.Media.Pen]::new((New-Brush '#FFFFFFFF'),2.2),$geometry);$context.Close()
    $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new(32,32,96,96,[Windows.Media.PixelFormats]::Pbgra32);$bitmap.Render($visual);$bitmap.Freeze()
    [Windows.Media.Imaging.BitmapFrame]::Create($bitmap)
}
$script:appIcon=New-AppIcon
$window.Icon=$script:appIcon
function Apply-RowTheme($item){
    if(!$item){return}
    $dark=$script:themeDark
    $item | Add-Member -NotePropertyName ModeLabel -NotePropertyValue $(switch($item.Mode){'토스 보유'{'토스 보유'}'수동 보유'{'수동 보유'}'관심 종목'{'관심 종목'}default{'위젯 종목'}}) -Force
    $item | Add-Member -NotePropertyName CanEditHolding -NotePropertyValue ($item.Mode -ne '토스 보유') -Force
    $item | Add-Member -NotePropertyName CanDelete -NotePropertyValue ($item.Mode -ne '토스 보유') -Force
    switch($item.Mode){
        '토스 보유' {
            $bBg=if($dark){'#FF2E2247'}else{'#FFF3E8FF'}
            $bFg=if($dark){'#FFC084FC'}else{'#FF7E22CE'}
            $bBd=if($dark){'#FF5B3A96'}else{'#FFD8B4FE'}
        }
        '수동 보유' {
            $bBg=if($dark){'#FF153445'}else{'#FFE0F2FE'}
            $bFg=if($dark){'#FF38BDF8'}else{'#FF0369A1'}
            $bBd=if($dark){'#FF255C7A'}else{'#FF7DD3FC'}
        }
        default {
            $bBg=if($dark){'#FF332915'}else{'#FFFEF3C7'}
            $bFg=if($dark){'#FFFBBF24'}else{'#FFB45309'}
            $bBd=if($dark){'#FF6B501C'}else{'#FFFCD34D'}
        }
    }
    $item | Add-Member -NotePropertyName ModeBadgeSurface -NotePropertyValue (New-Brush $bBg) -Force
    $item | Add-Member -NotePropertyName ModeBadgeBrush -NotePropertyValue (New-Brush $bFg) -Force
    $item | Add-Member -NotePropertyName ModeBadgeBorder -NotePropertyValue (New-Brush $bBd) -Force
}
function Apply-ComboColors($combo){
    if(!$combo){return}
    foreach($option in $combo.Items){
        if($option -is [Windows.Controls.ComboBoxItem]){
            if($option.IsSelected){$option.Background=New-Brush $(if($script:themeDark){'#FF22334D'}else{'#FFDCEBFF'});$option.Foreground=New-Brush $(if($script:themeDark){'#FF60A5FA'}else{'#FF124AA0'})}
            else{$option.ClearValue([Windows.Controls.Control]::BackgroundProperty);$option.Foreground=if($script:themeDark){New-Brush '#FFF2F4F7'}else{New-Brush '#FF191B20'}}
        }
    }
}
function Apply-Theme($target){
    $dark=$script:themeDark
    $main=[object]::ReferenceEquals($target,$window)
    $res=$target.Resources
    if($res){
        $res['WindowBgBrush']=New-Brush $(if($dark){'#FF111315'}else{'#FFF3F4F7'})
        $res['CardBgBrush']=New-Brush $(if($dark){'#FF1B1E22'}else{'#FFFFFFFF'})
        $res['SubCardBgBrush']=New-Brush $(if($dark){'#FF21252C'}else{'#FFF4F6F9'})
        $res['IndexBarBgBrush']=New-Brush $(if($dark){'#FF17191C'}else{'#FFE9ECF1'})
        $res['BorderLineBrush']=New-Brush $(if($dark){'#FF2D3138'}else{'#FFDDE1E7'})
        $res['TextPrimaryBrush']=New-Brush $(if($dark){'#FFF2F4F7'}else{'#FF191B20'})
        $res['TextSecondaryBrush']=New-Brush $(if($dark){'#FF9299A1'}else{'#FF646D7A'})
        $res['InputBgBrush']=New-Brush $(if($dark){'#FF14161A'}else{'#FFF8F9FB'})
        $res['ButtonBgBrush']=New-Brush $(if($dark){'#FF282C33'}else{'#FFEDF0F5'})
        $res['ButtonFgBrush']=New-Brush $(if($dark){'#FFE8ECF1'}else{'#FF263044'})
        $res['ScrollThumbBrush']=New-Brush $(if($dark){'#FF76818E'}else{'#FFA0AAB8'})
        $res['RowHoverBrush']=New-Brush $(if($dark){'#FF252A33'}else{'#FFF0F5FC'})
        $res['IndexCardBrush']=New-Brush $(if($dark){'#FF21252C'}else{'#FFFFFFFF'})
        $res['AddedSurfaceBrush']=New-Brush $(if($dark){'#FF262A32'}else{'#FFEFF2F6'})
    }
    if($main){
        $selection=if($dark){'#FF1B1E22'}else{'#FFFFFFFF'}
        $window.Resources[[Windows.SystemColors]::HighlightBrushKey]=New-Brush $selection
        $window.Resources[[Windows.SystemColors]::InactiveSelectionHighlightBrushKey]=New-Brush $selection
        $window.Resources[[Windows.SystemColors]::HighlightTextBrushKey]=New-Brush $(if($dark){'#FFF2F4F7'}else{'#FF191B20'})
        $window.Resources[[Windows.SystemColors]::InactiveSelectionHighlightTextBrushKey]=New-Brush $(if($dark){'#FFF2F4F7'}else{'#FF191B20'})
        if($script:apiConnectionState -eq '정상 연결'){
            $apiBanner.Background=if($dark){New-Brush '#FF172922'}else{New-Brush '#FFE8F7EF'}
            $apiBanner.BorderBrush=if($dark){New-Brush '#FF245B43'}else{New-Brush '#FFB8E3C9'}
        }elseif($script:credential){
            $apiBanner.Background=if($dark){New-Brush '#FF30291B'}else{New-Brush '#FFFFF4D8'}
            $apiBanner.BorderBrush=if($dark){New-Brush '#FF7A5817'}else{New-Brush '#FFE8C76C'}
        }else{
            $apiBanner.Background=if($dark){New-Brush '#FF20242A'}else{New-Brush '#FFF1F3F6'}
            $apiBanner.BorderBrush=if($dark){New-Brush '#FF343940'}else{New-Brush '#FFDDE1E6'}
        }
        Apply-ComboColors $market
        foreach($item in @($script:tableRows)){Apply-RowTheme $item}
        if($grid.Items){$grid.Items.Refresh()}
        if($results.Items){$results.Items.Refresh()}
        if($indexTicker.Items){$indexTicker.Items.Refresh()}
        $window.UpdateLayout()
    }
}
$settings=Join-Path $PSScriptRoot 'StockWidget.settings.json'
$script:credentialPath=Join-Path $PSScriptRoot 'StockWidget.toss.json'
$script:credential=$null
$script:apiConnectionState='연결 안 됨'
$script:apiConnectionDetail=''
if(Test-Path $script:credentialPath){try{$saved=Get-Content -Raw $script:credentialPath | ConvertFrom-Json;$secure=$saved.Secret | ConvertTo-SecureString;$script:credential=[pscredential]::new($saved.ClientId,$secure);$script:apiConnectionState='연결 확인 중'}catch{$script:apiConnectionState='저장 키 읽기 실패';$script:apiConnectionDetail=$_.Exception.Message}}
$entries=@()
if(Test-Path $settings){$entries=@((Get-Content -Encoding UTF8 -Raw $settings | ConvertFrom-Json) | Where-Object Id)}
foreach($entry in $entries){
    if($null -eq $entry.avgPrice){$entry | Add-Member -NotePropertyName avgPrice -NotePropertyValue ([decimal]$entry.Cost) -Force};if($null -eq $entry.quantity){$entry | Add-Member -NotePropertyName quantity -NotePropertyValue ([decimal]$entry.Qty) -Force}
    if($null -eq $entry.Cost){$entry | Add-Member -NotePropertyName Cost -NotePropertyValue ([decimal]$entry.avgPrice) -Force};if($null -eq $entry.Qty){$entry | Add-Member -NotePropertyName Qty -NotePropertyValue ([decimal]$entry.quantity) -Force}
    if($entry.Mode -notin '관심 종목','위젯 종목','수동 보유'){
        $entry.Mode=if($entry.Cost -gt 0 -and $entry.Qty -gt 0){'수동 보유'}else{'관심 종목'}
    }
}
$cards=@{}
$script:cards=$cards
$cardState=@{}
Apply-Theme $window

$script:indexRows=@()
$script:indexPage=0
$script:indexPageSize=4
function Set-IndexPage {
    $pageCount=[math]::Max(1,[math]::Ceiling($script:indexRows.Count/[double]$script:indexPageSize))
    if($script:indexPage -ge $pageCount){$script:indexPage=0}
    if($script:indexPage -lt 0){$script:indexPage=$pageCount-1}
    $start=$script:indexPage*$script:indexPageSize
    $pageItems=@($script:indexRows | Select-Object -Skip $start -First $script:indexPageSize)
    $indexTicker.ItemsSource=$pageItems
    $window.UpdateLayout()
    $visuals=[Collections.Generic.List[object]]::new();Add-VisualNodes $indexTicker $visuals
    $itemsGrid=$visuals | Where-Object {$_ -is [Windows.Controls.Primitives.UniformGrid]} | Select-Object -First 1
    if($itemsGrid -and $pageItems.Count){$itemsGrid.Columns=$pageItems.Count}
    $indexPageLabel.Text="$($script:indexPage+1) / $pageCount"
}
$indexPrev.Add_Click({$script:indexPage--;Set-IndexPage})
$indexNext.Add_Click({$script:indexPage++;Set-IndexPage})
$indexTimer=[Windows.Threading.DispatcherTimer]::new()
$indexTimer.Interval=[timespan]::FromSeconds(10)
$indexTimer.Add_Tick({$script:indexPage++;Set-IndexPage})
$workerText=Get-Content -Raw (Join-Path $PSScriptRoot 'StockQuotes.ps1')
$space=[runspacefactory]::CreateRunspace()
$space.Open()
function Save-Entries {
    $temp=$settings+'.'+$PID+'.tmp'
    foreach($entry in $script:entries){$entry.avgPrice=[decimal]$entry.Cost;$entry.quantity=[decimal]$entry.Qty}
    [IO.File]::WriteAllText($temp,(ConvertTo-Json -InputObject @($script:entries)),[Text.UTF8Encoding]::new($true))
    if([IO.File]::Exists($settings)){[IO.File]::Replace($temp,$settings,$settings+'.bak');[IO.File]::Delete($settings+'.bak')} else {[IO.File]::Move($temp,$settings)}
}
$script:lastRows=@()
$script:publicRows=@()
$script:holdingRows=@()
$script:queuedSections=@()
$script:jobSection='all'
$script:nextPublic=[datetime]::Now.AddSeconds(60)
$script:nextHolding=[datetime]::Now.AddSeconds(60)
function Fetch([string]$section='all') {
    if($script:job){
        if($section -eq 'holdings'){$script:queuedSections=@('holdings')+@($script:queuedSections | Where-Object {$_ -ne 'holdings'})}
        elseif($section -notin $script:queuedSections){$script:queuedSections+=@($section)}
        return
    }
    $script:job=[powershell]::Create()
    $job.Runspace=$space
    # Read the current script-scoped array so queued refreshes include newly added symbols.
    [void]$job.AddScript($workerText).AddArgument(@($script:entries)).AddArgument($script:credential).AddArgument($section)
    $script:jobSection=$section
    $script:pending=$job.BeginInvoke()
    $status.Text='시세를 조회하고 있어요…'
}
function Open-Card($items,[bool]$includeToss=$false,[string]$layout='group'){
    $members=@($items | Where-Object { $_ -and $_.Mode -ne '시장 지수' -and $_.Id -ne 'status' })
    $tossMembers=@();if($includeToss){$tossMembers=@($script:lastRows | Where-Object {$_.Mode -eq '토스 보유'});$members=@($tossMembers)+@($members | Where-Object {$_.Id -notin $tossMembers.Id})}
    if(!$members.Count){$status.Text='위젯에 띄울 종목을 먼저 켜 주세요.';return}
    $key=$layout+'|'+(($members.Id | Sort-Object) -join '|')
    if($cards.ContainsKey($key)){[void]$cards[$key].Activate();return}
    $panel=WindowFrom @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="주가 위젯" Width="430" MinWidth="280" SizeToContent="Height" MaxHeight="700" Background="Transparent" WindowStyle="None" AllowsTransparency="True" ShowInTaskbar="False" Topmost="False" FontFamily="Segoe UI, Malgun Gothic" Foreground="{DynamicResource TextPrimaryBrush}">
<Window.Resources>
<SolidColorBrush x:Key="CardBgBrush" Color="#FF16181C"/>
<SolidColorBrush x:Key="SubCardBgBrush" Color="#FF1F2329"/>
<SolidColorBrush x:Key="BorderLineBrush" Color="#FF2E333B"/>
<SolidColorBrush x:Key="TextPrimaryBrush" Color="#FFF2F4F7"/>
<SolidColorBrush x:Key="TextSecondaryBrush" Color="#FF9299A1"/>
<SolidColorBrush x:Key="ButtonBgBrush" Color="#FF282D36"/>
</Window.Resources>
<Border Name="widgetSurface" CornerRadius="18" Background="{DynamicResource CardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" Padding="15"><DockPanel><Border Name="header" DockPanel.Dock="Top" Background="Transparent" Padding="2,2,2,11"><DockPanel><StackPanel Name="headerActions" DockPanel.Dock="Right" Orientation="Horizontal" Visibility="Collapsed"><TextBlock Name="countLabel" VerticalAlignment="Center" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="12" Margin="0,0,8,0"/><Button Name="pinButton" Width="28" Height="28" Background="{DynamicResource ButtonBgBrush}" Foreground="{DynamicResource TextPrimaryBrush}" BorderThickness="0" Margin="0,0,5,0" FontSize="13" ToolTip="위치 고정" FontFamily="Segoe MDL2 Assets" Content="&#xE718;" Cursor="Hand"><Button.Template><ControlTemplate TargetType="Button"><Border Background="{TemplateBinding Background}" CornerRadius="8"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border></ControlTemplate></Button.Template></Button><Button Name="closeWidget" Width="28" Height="28" Background="{DynamicResource ButtonBgBrush}" Foreground="#F04452" BorderThickness="0" FontSize="12" FontFamily="Segoe MDL2 Assets" ToolTip="위젯 닫기" Content="&#xE711;" Cursor="Hand"><Button.Template><ControlTemplate TargetType="Button"><Border Background="{TemplateBinding Background}" CornerRadius="8"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border></ControlTemplate></Button.Template></Button></StackPanel><TextBlock Name="dragHandle" FontSize="15" FontWeight="Bold" Foreground="{DynamicResource TextPrimaryBrush}" VerticalAlignment="Center">관심 종목</TextBlock></DockPanel></Border>
<ScrollViewer VerticalScrollBarVisibility="Hidden" HorizontalScrollBarVisibility="Disabled" MaxHeight="595"><StackPanel><ItemsControl Name="quotes"><ItemsControl.ItemsPanel><ItemsPanelTemplate><UniformGrid Columns="1"/></ItemsPanelTemplate></ItemsControl.ItemsPanel><ItemsControl.ItemTemplate><DataTemplate><Border Name="stockTile" Background="{DynamicResource SubCardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="14" Padding="14,12" Margin="0,0,0,8"><StackPanel>
<DockPanel><TextBlock Text="{Binding MarketStatus}" DockPanel.Dock="Right" Foreground="{Binding MarketBrush}" FontSize="11" FontWeight="SemiBold" VerticalAlignment="Center"/><StackPanel><TextBlock Text="{Binding DisplayName}" Foreground="{DynamicResource TextPrimaryBrush}" FontSize="15" FontWeight="Bold" TextWrapping="Wrap"/><Border Background="#292F80FF" BorderBrush="#553A9BFF" BorderThickness="1" CornerRadius="7" Padding="6,1" Margin="0,4,0,0" HorizontalAlignment="Left" Visibility="{Binding TossBadgeVisibility}"><TextBlock Text="토스 보유" Foreground="#FF78B7FF" FontSize="9" FontWeight="Bold"/></Border></StackPanel></DockPanel>
<Grid Margin="0,8,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><Polyline Points="{Binding Sparkline}" Stroke="{Binding DayBrush}" StrokeThickness="1.8" Stretch="Fill" Width="110" Height="32" HorizontalAlignment="Left" VerticalAlignment="Center"/><StackPanel Grid.Column="1" HorizontalAlignment="Right"><TextBlock Text="{Binding Price}" Foreground="{DynamicResource TextPrimaryBrush}" FontSize="22" FontWeight="Bold" TextAlignment="Right"/><TextBlock Text="{Binding Delta}" FontSize="12" Foreground="{Binding DayBrush}" FontWeight="SemiBold" TextAlignment="Right" Margin="0,2,0,0"/></StackPanel></Grid>
<Border Visibility="{Binding GainVisibility}" Background="{Binding GainSurface}" BorderBrush="{Binding GainBrush}" BorderThickness="1.5" CornerRadius="11" Padding="12,9" Margin="0,9,0,0"><DockPanel><StackPanel Orientation="Horizontal" VerticalAlignment="Center"><TextBlock Text="◈" Foreground="{Binding GainBrush}" FontSize="14" Margin="0,0,7,0"/><TextBlock Text="{Binding GainLabel}" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="12" FontWeight="SemiBold" VerticalAlignment="Center"/></StackPanel><StackPanel DockPanel.Dock="Right" HorizontalAlignment="Right"><TextBlock Text="{Binding GainPnl}" Foreground="{Binding GainBrush}" FontWeight="Bold" FontSize="15" TextAlignment="Right"/><TextBlock Text="{Binding GainCard}" Foreground="{Binding GainBrush}" FontWeight="SemiBold" FontSize="12" TextAlignment="Right" Margin="0,2,0,0"/></StackPanel></DockPanel></Border>
<TextBlock Text="{Binding Stamp}" FontSize="10" Foreground="{DynamicResource TextSecondaryBrush}" Margin="0,4,0,0"/></StackPanel></Border></DataTemplate></ItemsControl.ItemTemplate></ItemsControl><ItemsControl Name="groupQuotes" Visibility="Collapsed"><ItemsControl.ItemTemplate><DataTemplate><Border Name="stockTile" Background="{DynamicResource SubCardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="12" Padding="13,10" Margin="0,0,0,7"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="2.2*"/><ColumnDefinition Width="96"/><ColumnDefinition Width="150"/></Grid.ColumnDefinitions><StackPanel VerticalAlignment="Center"><TextBlock Text="{Binding DisplayName}" Foreground="{DynamicResource TextPrimaryBrush}" FontSize="14" FontWeight="Bold" TextWrapping="Wrap"/><Border Background="#292F80FF" BorderBrush="#553A9BFF" BorderThickness="1" CornerRadius="7" Padding="6,1" Margin="0,4,0,0" HorizontalAlignment="Left" Visibility="{Binding TossBadgeVisibility}"><TextBlock Text="토스 보유" Foreground="#FF78B7FF" FontSize="9" FontWeight="Bold"/></Border><TextBlock Text="{Binding MarketStatus}" Foreground="{Binding MarketBrush}" FontSize="11" FontWeight="SemiBold" Margin="0,3,0,0"/><Border Visibility="{Binding GainVisibility}" Background="{Binding GainSurface}" BorderBrush="{Binding GainBrush}" BorderThickness="1.5" CornerRadius="9" Padding="9,6" Margin="0,6,0,0"><DockPanel><StackPanel Orientation="Horizontal" VerticalAlignment="Center"><TextBlock Text="◈" Foreground="{Binding GainBrush}" FontSize="11" Margin="0,0,5,0"/><TextBlock Text="{Binding GainLabel}" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="9" VerticalAlignment="Center"/></StackPanel><StackPanel DockPanel.Dock="Right" HorizontalAlignment="Right"><TextBlock Text="{Binding GainPnl}" Foreground="{Binding GainBrush}" FontWeight="Bold" FontSize="12" TextAlignment="Right"/><TextBlock Text="{Binding GainCard}" Foreground="{Binding GainBrush}" FontWeight="SemiBold" FontSize="9" TextAlignment="Right"/></StackPanel></DockPanel></Border></StackPanel><Polyline Grid.Column="1" Points="{Binding Sparkline}" Stroke="{Binding DayBrush}" StrokeThickness="1.7" Stretch="Fill" Width="82" Height="28" VerticalAlignment="Center"/><StackPanel Grid.Column="2" HorizontalAlignment="Right" VerticalAlignment="Center"><TextBlock Text="{Binding Price}" Foreground="{DynamicResource TextPrimaryBrush}" FontSize="16" FontWeight="Bold" TextAlignment="Right"/><TextBlock Text="{Binding Delta}" Foreground="{Binding DayBrush}" FontSize="12" FontWeight="SemiBold" TextAlignment="Right" TextWrapping="Wrap" Margin="0,2,0,0"/></StackPanel></Grid></Border></DataTemplate></ItemsControl.ItemTemplate></ItemsControl></StackPanel></ScrollViewer></DockPanel></Border></Window>
"@
    $panel.Width=if($layout -eq 'single'){310}else{540}
    $panel.MinWidth=if($layout -eq 'single'){280}else{460}
    $panel.FindName('dragHandle').Text=if($layout -eq 'single' -and $members[0].Mode -eq '토스 보유'){'토스 보유 종목'}elseif($layout -eq 'single'){$members[0].DisplayName}elseif(@($members | Where-Object Mode -eq '토스 보유').Count -eq $members.Count){'토스 보유 종목'}else{'내 주식'}
    $panel.Tag=$key
    $panel.FindName('closeWidget').Add_Click({$panel.Close()}.GetNewClosure())
    $panel.Add_StateChanged({if($panel.WindowState -eq 'Minimized'){$panel.WindowState='Normal'}}.GetNewClosure())
    $panel.Add_MouseEnter({$panel.FindName('headerActions').Visibility='Visible'}.GetNewClosure())
    $panel.Add_MouseLeave({$panel.FindName('headerActions').Visibility='Collapsed'}.GetNewClosure())
    $panel.FindName('pinButton').Add_Click({$state=$cardState[$key];$state.LocationLocked=-not [bool]$state.LocationLocked;$pin=$panel.FindName('pinButton');$pin.Foreground=if($state.LocationLocked){New-Brush '#FF3A9BFF'}else{New-Brush '#FF9299A1'};$pin.ToolTip=if($state.LocationLocked){'위치 고정됨 (클릭 시 해제)'}else{'위치 고정'}}.GetNewClosure())
    $panel.FindName('dragHandle').Add_MouseLeftButtonDown({param($sender,$e) if($e.ClickCount -eq 1 -and -not $cardState[$key].LocationLocked){$panel.DragMove()}}.GetNewClosure())
    $cardState[$key]=@{Panel=$panel;Items=$members;IncludeToss=$includeToss;Layout=$layout;Ids=@($members.Id);LocationLocked=$false}
    foreach($member in $members){$member | Add-Member -NotePropertyName TossBadgeVisibility -NotePropertyValue $(if($member.Mode -eq '토스 보유'){'Visible'}else{'Collapsed'}) -Force}
    $panel.FindName('quotes').ItemsSource=$members
    $panel.FindName('quotes').Visibility=if($layout -eq 'single'){'Visible'}else{'Collapsed'}
    $panel.FindName('groupQuotes').ItemsSource=$members
    $panel.FindName('groupQuotes').Visibility=if($layout -eq 'group'){'Visible'}else{'Collapsed'}
    $panel.FindName('countLabel').Text="$($members.Count)종목"
    $cards[$key]=$panel
    $panel.Add_Closed({param($sender,$args) $cards.Remove($key);$cardState.Remove($key)}.GetNewClosure())
    $panel.Topmost=$script:alwaysTop
    $panel.Show()
    Apply-Theme $panel
}
function Sync-Cards($rows){
    foreach($key in @($cards.Keys)){
        $state=$cardState[$key]
        $ids=@($state.Ids)
        if($state.Layout -eq 'group'){$members=@($rows | Where-Object {$_.WidgetVisible -and $_.Mode -ne '시장 지수' -and $_.Id -ne 'status'})}else{$members=@($rows | Where-Object {$_.Id -in $ids -and $_.WidgetVisible -ne $false})}
        if($state.Layout -ne 'group' -and ($state.IncludeToss -or @($ids | Where-Object {$_ -like 'toss-*' -or $_ -like 'account-*'}).Count -gt 0)){$tossMembers=@($rows | Where-Object {$_.Mode -eq '토스 보유'});$members=@($tossMembers)+@($members | Where-Object {$_.Id -notin $tossMembers.Id})}
        if(!$members.Count){$cards[$key].Close();continue}
        foreach($member in $members){$member | Add-Member -NotePropertyName TossBadgeVisibility -NotePropertyValue $(if($member.Mode -eq '토스 보유'){'Visible'}else{'Collapsed'}) -Force}
        $state.Panel.FindName('dragHandle').Text=if($state.Layout -eq 'single' -and $members[0].Mode -eq '토스 보유'){'토스 보유 종목'}elseif($state.Layout -eq 'single'){$members[0].DisplayName}elseif(@($members | Where-Object Mode -eq '토스 보유').Count -eq $members.Count){'토스 보유 종목'}else{'내 주식'}
        $state.Items=$members
        $state.Panel.FindName('quotes').ItemsSource=$members
        $state.Panel.FindName('groupQuotes').ItemsSource=$members
        $state.Panel.FindName('countLabel').Text="$($members.Count)종목"
    }
}
function Update-TableView {
    $filterAll.Content="전체 $($script:tableRows.Count)"
    $widgetOnCount=@($script:tableRows | Where-Object WidgetVisible).Count
    $filterWidgets.Content="위젯 표시 중 $widgetOnCount"
    $holdingModes=@('토스 보유','수동 보유')
    $filterHoldings.Content="보유 주식 $(@($script:tableRows | Where-Object {$_.Mode -in $holdingModes}).Count)"
    $group.Content="묶어 띄우기 · $($widgetOnCount)개"
    $filterAll.IsChecked=$script:tableFilter -eq 'all';$filterWidgets.IsChecked=$script:tableFilter -eq 'widgets';$filterHoldings.IsChecked=$script:tableFilter -eq 'holdings'
    $visible=switch($script:tableFilter){'widgets'{@($script:tableRows | Where-Object WidgetVisible)}'holdings'{@($script:tableRows | Where-Object {$_.Mode -in $holdingModes})}default{@($script:tableRows)}}
    $grid.ItemsSource=@($visible)
}
$filterAll.Add_Click({$script:tableFilter='all';Update-TableView})
$filterWidgets.Add_Click({$script:tableFilter='widgets';Update-TableView})
$filterHoldings.Add_Click({$script:tableFilter='holdings';Update-TableView})
$widgetClickHandler=[Windows.RoutedEventHandler]{param($sender,$e);$toggle=$e.OriginalSource -as [Windows.Controls.Primitives.ToggleButton];if(!$toggle -or $toggle.Name -ne 'widgetToggle'){return};$item=$toggle.DataContext;if(!$item){return};$script:widgetVisibility[[string]$item.Id]=[bool]$toggle.IsChecked;$item.WidgetVisible=[bool]$toggle.IsChecked;$item.WidgetLabel=if($item.WidgetVisible){'ON'}else{'OFF'};$item.WidgetBrush=if($item.WidgetVisible){New-Brush '#FF2D7FF9'}else{New-Brush '#FF8993A0'};Save-Preferences;Update-TableView;Sync-Cards $script:lastRows}.GetNewClosure()
$grid.AddHandler([Windows.Controls.Primitives.ButtonBase]::ClickEvent,$widgetClickHandler,$true)
$group.Add_Click({$selection=@($script:tableRows | Where-Object WidgetVisible);$group.Content="묶어 띄우기 · $($selection.Count)개";if(!$selection.Count){$status.Text='먼저 위젯 표시 스위치를 켜 주세요.';return};Open-Card $selection $false 'group'})
$pop.Add_Click({$targets=@($grid.SelectedItems);if(!$targets.Count){$targets=@($script:tableRows | Where-Object WidgetVisible)};foreach($item in $targets){Open-Card $item $false 'single'}})
$grid.Add_MouseDoubleClick({Open-Card $grid.SelectedItem $false 'single'})
$tossGrid.Add_MouseDoubleClick({Open-Card $tossGrid.SelectedItem $false 'single'})
function Add-Candidate($candidate){
    if(!$candidate){$status.Text='오른쪽에서 종목을 선택하세요.';return}
    if(@($script:entries | Where-Object Symbol -eq $candidate.Symbol).Count){$status.Text='이미 목록에 추가된 종목이에요.';return}
    $newId=[guid]::NewGuid().ToString()
    $newEntry=[pscustomobject]@{Id=$newId;Symbol=$candidate.Symbol;Name=$candidate.Name;Mode='관심 종목';Cost=[decimal]0;Qty=[decimal]0;avgPrice=[decimal]0;quantity=[decimal]0}
    $script:entries+=@($newEntry)
    $script:widgetVisibility[$newId]=$true
    $optimisticRow=[pscustomobject]@{
        Id=$newId;Name=$candidate.Name;DisplayName=$candidate.Name;Symbol=$candidate.Symbol;Mode='관심 종목';
        Price=$candidate.Price;Delta='시세 동기화 중…';DayBrush=(New-Brush '#FF9299A1');
        GainDisplay='—';GainPnl='';GainBrush=(New-Brush '#FF9299A1');
        MarketStatus='조회 중';MarketBrush=(New-Brush '#FF9299A1');StatusLine='시세 확인 중…';
        ClosedStatusVisibility='Visible';BadgeStatusVisibility='Collapsed';StatusSurface=(New-Brush '#FF292D33');
        WidgetVisible=$true;WidgetLabel='ON';WidgetBrush=(New-Brush '#FF2D7FF9')
    }
    Apply-RowTheme $optimisticRow
    $script:tableRows=@($optimisticRow)+@($script:tableRows)
    $script:lastRows=@($optimisticRow)+@($script:lastRows)
    Set-CandidateStates $results.ItemsSource
    foreach($ck in @($rankCache.Keys)){Set-CandidateStates $rankCache[$ck].rows}
    if($results.Items){$results.Items.Refresh()}
    Update-TableView
    Save-Preferences
    try { Save-Entries } catch { $status.Text="관심 종목은 추가했지만 저장에 실패했어요 · $($_.Exception.Message)"; return }
    Fetch 'public'
}
function Remove-SelectedEntry {
    if(!$grid.SelectedItem){return}
    if($grid.SelectedItem.Mode -eq '토스 보유'){return}
    $id=[string]$grid.SelectedItem.Id
    $sym=[string]$grid.SelectedItem.Symbol
    [void]$script:deletedIds.Add($id)
    $script:tableRows=@($script:tableRows | Where-Object {[string]$_.Id -ne $id})
    $script:lastRows=@($script:lastRows | Where-Object {[string]$_.Id -ne $id})
    $script:publicRows=@($script:publicRows | Where-Object {[string]$_.Id -ne $id})
    $script:holdingRows=@($script:holdingRows | Where-Object {[string]$_.Id -ne $id})
    $isLocal=$id -in @($script:entries | ForEach-Object {[string]$_.Id})
    if($isLocal){$script:entries=@($script:entries | Where-Object {[string]$_.Id -ne $id});$script:widgetVisibility.Remove($id)}
    else{$script:hiddenRows=@($script:hiddenRows)+$id;$script:hiddenRows=@($script:hiddenRows | Select-Object -Unique)}
    Set-CandidateStates $results.ItemsSource
    foreach($ck in @($rankCache.Keys)){Set-CandidateStates $rankCache[$ck].rows}
    if($results.Items){$results.Items.Refresh()}
    Update-TableView
    Sync-Cards $script:lastRows
    if($isLocal){Save-Entries}
    Save-Preferences
}
function Open-ManualHolding($row){
    if(!$row -or $row.Mode -eq '토스 보유'){return}
    $entry=$script:entries | Where-Object Id -eq $row.Id | Select-Object -First 1
    if(!$entry){return}
    $raw=[regex]::Replace([string]$row.Price,'[^0-9.,-]','').Replace(',','')
    $current=[decimal]0;$hasQuote=[decimal]::TryParse($raw,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$current)
    $dark=$script:themeDark
    $dCard=if($dark){'#FF1B1E22'}else{'#FFFFFFFF'}
    $dSub=if($dark){'#FF242830'}else{'#FFF4F6F9'}
    $dBorder=if($dark){'#FF323741'}else{'#FFD8DDE6'}
    $dFg=if($dark){'#FFF2F4F7'}else{'#FF191B20'}
    $dSubFg=if($dark){'#FF9299A1'}else{'#FF646D7A'}
    $dBtnBg=if($dark){'#FF2A2F38'}else{'#FFEDF0F5'}
    $currencyUnit=([string]$row.Price -replace '^[0-9.,-]+\s*','').Trim()
    if(!$currencyUnit){$currencyUnit='KRW'}
    $dialog=WindowFrom @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="수동 보유 설정" Width="430" SizeToContent="Height" WindowStartupLocation="CenterOwner" ResizeMode="NoResize" WindowStyle="None" AllowsTransparency="True" Background="Transparent" Foreground="$dFg" FontFamily="Malgun Gothic">
<Border Background="$dCard" BorderBrush="$dBorder" BorderThickness="1" CornerRadius="20" Padding="24" Margin="8">
<Border.Effect><DropShadowEffect Color="Black" BlurRadius="18" ShadowDepth="4" Opacity="0.35"/></Border.Effect>
<StackPanel>
<DockPanel><Button Name="cancelTop" DockPanel.Dock="Right" Content="×" Width="30" Height="30" Background="Transparent" Foreground="$dSubFg" BorderThickness="0" FontSize="18" Cursor="Hand"/><TextBlock Text="수동 보유 설정" FontSize="20" FontWeight="Bold" VerticalAlignment="Center"/></DockPanel>
<TextBlock Name="holdingName" FontSize="15" FontWeight="SemiBold" Margin="0,14,0,2"/><TextBlock Name="holdingQuote" Foreground="$dSubFg" FontSize="12" Margin="0,0,0,18"/>
<TextBlock Text="평균 매수가 (1주 가격)" FontSize="12" FontWeight="SemiBold" Foreground="$dSubFg"/>
<Border Background="$dSub" BorderBrush="$dBorder" BorderThickness="1" CornerRadius="10" Padding="10,6" Margin="0,5,0,14"><DockPanel><TextBlock Text="$currencyUnit" DockPanel.Dock="Right" Foreground="$dSubFg" VerticalAlignment="Center" Margin="8,0,0,0" FontSize="12"/><TextBox Name="avgPriceInput" Background="Transparent" Foreground="$dFg" BorderThickness="0" FontSize="15" VerticalContentAlignment="Center"/></DockPanel></Border>
<TextBlock Text="보유 수량 (소수점 입력 가능)" FontSize="12" FontWeight="SemiBold" Foreground="$dSubFg"/>
<Border Background="$dSub" BorderBrush="$dBorder" BorderThickness="1" CornerRadius="10" Padding="10,6" Margin="0,5,0,16"><DockPanel><TextBlock Text="주" DockPanel.Dock="Right" Foreground="$dSubFg" VerticalAlignment="Center" Margin="8,0,0,0" FontSize="12"/><TextBox Name="quantityInput" Background="Transparent" Foreground="$dFg" BorderThickness="0" FontSize="15" VerticalContentAlignment="Center"/></DockPanel></Border>
<Border Background="$dSub" BorderBrush="$dBorder" BorderThickness="1" CornerRadius="12" Padding="14" Margin="0,0,0,18"><StackPanel><TextBlock Text="예상 평가손익" Foreground="$dSubFg" FontSize="12"/><TextBlock Name="previewPnl" FontSize="17" FontWeight="Bold" Margin="0,4,0,0"/><TextBlock Name="previewRate" Foreground="$dSubFg" FontSize="12" Margin="0,2,0,0"/></StackPanel></Border>
<DockPanel><Button Name="releaseHolding" DockPanel.Dock="Left" Content="보유 해제" Padding="12,8" Background="Transparent" Foreground="#F04452" BorderThickness="0" FontWeight="SemiBold" Cursor="Hand"/><StackPanel Orientation="Horizontal" HorizontalAlignment="Right"><Button Name="cancelHolding" Content="취소" Padding="16,8" Background="$dBtnBg" Foreground="$dFg" BorderThickness="0" Margin="0,0,8,0" Cursor="Hand"/><Button Name="saveHolding" Content="저장" Padding="20,8" Background="#2F80FF" Foreground="White" BorderThickness="0" FontWeight="SemiBold" Cursor="Hand"/></StackPanel></DockPanel>
</StackPanel></Border></Window>
"@
    $dialog.Owner=$window
    $name=$dialog.FindName('holdingName');$name.Text=[string]$row.DisplayName
    $quote=$dialog.FindName('holdingQuote');$quote.Text=if($hasQuote){"현재가 $($row.Price)"}else{'현재 시세를 불러오지 못했어요.'}
    $avg=$dialog.FindName('avgPriceInput');$qty=$dialog.FindName('quantityInput');$previewPnl=$dialog.FindName('previewPnl');$previewRate=$dialog.FindName('previewRate')
    $avg.Text=if($entry.avgPrice){[string]$entry.avgPrice}elseif($entry.Cost){[string]$entry.Cost}else{''};$qty.Text=if($entry.quantity){[string]$entry.quantity}elseif($entry.Qty){[string]$entry.Qty}else{''}
    $refreshPreview={
        $a=[decimal]0;$q=[decimal]0
        $okA=[decimal]::TryParse($avg.Text,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::CurrentCulture,[ref]$a);if(!$okA){$okA=[decimal]::TryParse($avg.Text.Replace(',',''),[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$a)}
        $okQ=[decimal]::TryParse($qty.Text,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::CurrentCulture,[ref]$q);if(!$okQ){$okQ=[decimal]::TryParse($qty.Text.Replace(',',''),[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$q)}
        if($hasQuote -and $okA -and $a -gt 0 -and $okQ -and $q -gt 0){$pnl=($current-$a)*$q;$rate=($current/$a)-1;$previewPnl.Text=('{0:+#,##0.####;-#,##0.####;0}' -f $pnl)+" $currencyUnit";$previewPnl.Foreground=if($pnl -lt 0){New-Brush '#FF3A9BFF'}elseif($pnl -gt 0){New-Brush '#FFFF4967'}else{New-Brush '#FF9299A1'};$previewRate.Text=('{0:+0.00%;-0.00%;0.00%}' -f $rate)}else{$previewPnl.Text='평단가와 수량을 입력하면 계산돼요.';$previewPnl.Foreground=New-Brush $dFg;$previewRate.Text=''}
    }.GetNewClosure()
    $avg.Add_TextChanged($refreshPreview);$qty.Add_TextChanged($refreshPreview);& $refreshPreview
    $dialog.FindName('cancelTop').Add_Click({$dialog.Close()}.GetNewClosure());$dialog.FindName('cancelHolding').Add_Click({$dialog.Close()}.GetNewClosure())
    $dialog.FindName('saveHolding').Add_Click({
        $a=[decimal]0;$q=[decimal]0
        if(![decimal]::TryParse($avg.Text.Replace(',',''),[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$a) -or $a -le 0){[Windows.MessageBox]::Show('평균 매수가를 올바르게 입력해 주세요.','수동 보유 설정')|Out-Null;return}
        if(![decimal]::TryParse($qty.Text.Replace(',',''),[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$q) -or $q -le 0){[Windows.MessageBox]::Show('보유 수량을 올바르게 입력해 주세요.','수동 보유 설정')|Out-Null;return}
        $entry.Mode='수동 보유';$entry.Cost=$a;$entry.Qty=$q;$entry.avgPrice=$a;$entry.quantity=$q
        $row.Mode='수동 보유'
        if($hasQuote){
            $pnl=($current-$a)*$q;$rate=($current/$a)-1
            $row.GainDisplay=('{0:+0.00%;-0.00%;0.00%}' -f $rate)
            $row.GainCard=$row.GainDisplay
            $row.GainPnl=('{0:+#,##0.####;-#,##0.####;0}' -f $pnl)+" $currencyUnit"
            $row.GainBrush=if($pnl -lt 0){New-Brush '#FF3A9BFF'}elseif($pnl -gt 0){New-Brush '#FFFF4967'}else{New-Brush '#FF9299A1'}
            $row.GainSurface=if($pnl -lt 0){New-Brush '#243A9BFF'}elseif($pnl -gt 0){New-Brush '#24FF4967'}else{New-Brush '#1A9299A1'}
            $row.GainVisibility='Visible'
        }
        Apply-RowTheme $row;Update-TableView;$grid.Items.Refresh();Save-Entries;$dialog.Close();Fetch 'public'
    }.GetNewClosure())
    $dialog.FindName('releaseHolding').Add_Click({
        $entry.Mode='관심 종목';$entry.Cost=0;$entry.Qty=0;$entry.avgPrice=0;$entry.quantity=0
        $row.Mode='관심 종목';$row.GainDisplay='—';$row.GainCard='';$row.GainPnl='';$row.GainLabel='';$row.GainVisibility='Collapsed';$row.GainBrush=(New-Brush '#FF9299A1');$row.GainSurface=(New-Brush '#1A9299A1')
        Apply-RowTheme $row;Update-TableView;$grid.Items.Refresh();Save-Entries;$dialog.Close();Fetch 'public'
    }.GetNewClosure())
    [void]$dialog.ShowDialog()
}
$grid.AddHandler([Windows.Controls.Primitives.ButtonBase]::ClickEvent,[Windows.RoutedEventHandler]{param($sender,$e);$button=$e.OriginalSource;while($button -and -not ($button -is [Windows.Controls.Button])){$button=[Windows.Media.VisualTreeHelper]::GetParent($button)};if(!$button){return};if($button.Name -eq 'rowRemove'){$grid.SelectedItem=$button.DataContext;Remove-SelectedEntry}elseif($button.Name -in 'editHoldingBadge','editHoldingGain'){Open-ManualHolding $button.DataContext}}.GetNewClosure(),$true)
$settingsButton.Add_Click({
    $dialog=WindowFrom @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="주가 위젯 설정" Width="520" SizeToContent="Height"  ResizeMode="NoResize" WindowStartupLocation="CenterOwner" Background="{DynamicResource WindowBgBrush}" Foreground="{DynamicResource TextPrimaryBrush}" FontFamily="Malgun Gothic">
<Window.Resources>
<SolidColorBrush x:Key="WindowBgBrush" Color="#FF17191D"/>
<SolidColorBrush x:Key="CardBgBrush" Color="#FF22262C"/>
<SolidColorBrush x:Key="BorderLineBrush" Color="#FF323741"/>
<SolidColorBrush x:Key="TextPrimaryBrush" Color="#FFF2F4F7"/>
<SolidColorBrush x:Key="TextSecondaryBrush" Color="#FF9EA6B1"/>
<SolidColorBrush x:Key="InputBgBrush" Color="#FF2B3037"/>
<SolidColorBrush x:Key="ButtonBgBrush" Color="#FF282C32"/>
<Style TargetType="Button"><Setter Property="Cursor" Value="Hand"/><Setter Property="Background" Value="{DynamicResource ButtonBgBrush}"/><Setter Property="Foreground" Value="{DynamicResource TextPrimaryBrush}"/><Setter Property="FontSize" Value="14"/><Setter Property="Padding" Value="9,6"/><Setter Property="Margin" Value="3"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="surface" Background="{TemplateBinding Background}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="10" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="surface" Property="Opacity" Value=".82"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
</Window.Resources>
<Border Name="settingsCard" Background="{DynamicResource WindowBgBrush}" Padding="26"><StackPanel><DockPanel Margin="0,0,0,8"><Border Width="38" Height="38" CornerRadius="11" Background="#FF2F80FF" Margin="0,0,12,0"><TextBlock Text="₩" FontSize="21" FontWeight="Bold" Foreground="White" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><StackPanel VerticalAlignment="Center"><TextBlock Text="주가 위젯 설정" FontSize="22" FontWeight="Bold"/><TextBlock Text="위젯 표시와 토스증권 연결을 관리합니다." Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11" Margin="0,3,0,0"/></StackPanel></DockPanel><Border Height="1" Background="{DynamicResource BorderLineBrush}" Margin="0,4,0,17"/><Border Name="topmostCard" Background="{DynamicResource CardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="14" Padding="14" Margin="0,0,0,14"><DockPanel><StackPanel><TextBlock Text="항상 맨 위에 표시" FontSize="14" FontWeight="SemiBold"/><TextBlock Text="켜면 위젯이 다른 창보다 항상 위에 표시됩니다." Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11" Margin="0,4,0,0"/></StackPanel><ToggleButton Name="alwaysTop" DockPanel.Dock="Right" Width="54" Height="30" VerticalAlignment="Center" Background="#41464F" BorderThickness="0"><ToggleButton.Template><ControlTemplate TargetType="ToggleButton"><Grid Width="54" Height="30"><Border x:Name="SwitchTrack" Background="#41464F" CornerRadius="15"/><Ellipse x:Name="SwitchThumb" Width="24" Height="24" Fill="White" HorizontalAlignment="Left" Margin="3"/></Grid><ControlTemplate.Triggers><Trigger Property="IsChecked" Value="True"><Setter TargetName="SwitchTrack" Property="Background" Value="#30C759"/><Setter TargetName="SwitchThumb" Property="HorizontalAlignment" Value="Right"/></Trigger></ControlTemplate.Triggers></ControlTemplate></ToggleButton.Template></ToggleButton></DockPanel></Border><Border Name="apiCard" Background="{DynamicResource CardBgBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1" CornerRadius="14" Padding="16"><StackPanel><DockPanel><TextBlock Text="토스증권 연결" FontSize="15" FontWeight="SemiBold"/><TextBlock Name="apiState" DockPanel.Dock="Right" Foreground="{DynamicResource TextSecondaryBrush}"/></DockPanel><TextBlock Text="API 키를 연결하면 보유 종목과 계좌 정보가 표시됩니다." TextWrapping="Wrap" Foreground="{DynamicResource TextSecondaryBrush}" Margin="0,5,0,12"/><TextBlock Text="Client ID" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="12"/><TextBox Name="client" Margin="0,4,0,10" Padding="10" Background="{DynamicResource InputBgBrush}" Foreground="{DynamicResource TextPrimaryBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1"/><TextBlock Text="Client Secret" Foreground="{DynamicResource TextSecondaryBrush}" FontSize="12"/><PasswordBox Name="secret" Margin="0,4,0,14" Padding="10" Background="{DynamicResource InputBgBrush}" Foreground="{DynamicResource TextPrimaryBrush}" BorderBrush="{DynamicResource BorderLineBrush}" BorderThickness="1"/><WrapPanel><Button Name="ok" Content="연결" Padding="18,9" Background="#2F80FF" Foreground="White" BorderThickness="0" FontWeight="SemiBold"/><Button Name="off" Content="연결 해제" Margin="8,0,0,0" Padding="14,9"/></WrapPanel></StackPanel></Border><TextBlock Text="연결 정보는 이 Windows 계정에서만 복호화되도록 저장합니다." Foreground="{DynamicResource TextSecondaryBrush}" FontSize="11" Margin="2,14,0,0" TextWrapping="Wrap"/></StackPanel></Border></Window>
"@
    $dialog.Icon=$script:appIcon
    $dialog.Owner=$window
    $apiState=$dialog.FindName('apiState');$apiState.Text=if($script:credential){"● 키 저장됨 · $script:apiConnectionState"}elseif($script:apiConnectionDetail){"● 키 읽기 오류 · $script:apiConnectionDetail"}else{'○ 연결 안 됨'};$apiState.Foreground=if($script:credential -and $script:apiConnectionState -eq '정상 연결'){New-Brush '#FF20B486'}elseif($script:credential -or $script:apiConnectionDetail){New-Brush '#FFE5484D'}else{New-Brush '#FF9299A1'}
    $alwaysTop=$dialog.FindName('alwaysTop');$alwaysTop.IsChecked=$script:alwaysTop
    $script:alwaysTopControl=$alwaysTop
    $alwaysTop.Add_Checked({$script:alwaysTop=[bool]$script:alwaysTopControl.IsChecked;Save-Preferences;foreach($card in @($script:cards.Values)){$card.Topmost=$script:alwaysTop}})
    $alwaysTop.Add_Unchecked({$script:alwaysTop=[bool]$script:alwaysTopControl.IsChecked;Save-Preferences;foreach($card in @($script:cards.Values)){$card.Topmost=$script:alwaysTop}})
    Apply-Theme $dialog
    $client=$dialog.FindName('client')
    $secret=$dialog.FindName('secret')
    $canEditApi=(!$script:credential -or $script:apiConnectionState -ne '정상 연결')
    $client.IsEnabled=$canEditApi
    $secret.IsEnabled=$canEditApi
    if($script:credential -and $canEditApi){$client.Text=$script:credential.UserName}
    $dialog.FindName('ok').IsEnabled=$canEditApi
    $dialog.FindName('off').IsEnabled=([bool]$script:credential -or [bool]$script:apiConnectionDetail)
    $dialog.FindName('ok').Add_Click({if($client.Text.Trim() -and $secret.SecurePassword.Length){$dialog.Tag='connect';$dialog.DialogResult=$true}})
    $dialog.FindName('off').Add_Click({$dialog.Tag='off';$dialog.DialogResult=$true})
    if($dialog.ShowDialog()){
        if($script:job){$job.Stop();$job.Dispose();$script:job=$null}
        $space.SessionStateProxy.SetVariable('token',$null)
        $script:credential=if($dialog.Tag -eq 'connect'){[pscredential]::new($client.Text.Trim(),$secret.SecurePassword);$protected=$secret.SecurePassword | ConvertFrom-SecureString;[IO.File]::WriteAllText($script:credentialPath,(ConvertTo-Json @{ClientId=$client.Text.Trim();Secret=$protected}),[Text.Encoding]::UTF8)}else{if(Test-Path $script:credentialPath){Remove-Item -LiteralPath $script:credentialPath};$null}
        $secret.Clear()
        $script:queuedSections=@()
        $script:apiConnectionState=if($script:credential){'연결 확인 중'}else{'연결 안 됨'};$script:apiConnectionDetail=''
        $visiblePublic=@($grid.ItemsSource | Where-Object {$_.Id -ne 'status'});$tossGrid.ItemsSource=@();$tossStatus.Text=if($script:credential){'● 키 저장됨 · 토스 API 응답을 확인하고 있어요.'}else{'○ API 연결 안 됨 · 설정에서 토스 API를 연결하세요.'};$tossStatus.Foreground=if($script:credential){New-Brush '#FFF0A542'}else{New-Brush '#FF9299A1'}
        $grid.ItemsSource=$visiblePublic
        Sync-Cards @($visiblePublic)
        Fetch 'holdings'
    }
})
$checkSettings.Add_Click({$settingsButton.RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Primitives.ButtonBase]::ClickEvent))})
$retryApi.Add_Click({if(!$script:credential){$status.Text='먼저 설정에서 토스 API 키를 연결하세요.'}else{$script:nextHolding=[datetime]::Now.AddSeconds(60);Fetch 'holdings'}})
$update.Add_Click({Fetch})
$timer=[Windows.Threading.DispatcherTimer]::new()
$timer.Interval=[timespan]::FromMilliseconds(250)
$timer.Add_Tick({
    if($job -and $pending.IsCompleted){
        $completedSection=$script:jobSection
        try{
            $resultRows=@($job.EndInvoke($pending))
            if($completedSection -eq 'all'){
                $script:publicRows=@($resultRows | Where-Object {$_.Mode -notin '토스 보유','연동'})
                $script:holdingRows=@($resultRows | Where-Object {$_.Mode -in '토스 보유','연동'})
            }elseif($completedSection -eq 'public'){$script:publicRows=$resultRows}
            elseif($completedSection -eq 'holdings'){$script:holdingRows=$resultRows}
            $validLocalIds=@($script:entries | ForEach-Object {[string]$_.Id})
            $rows=@($script:publicRows)+@($script:holdingRows)
            $rows=@($rows | Where-Object {
                $rid=[string]$_.Id
                if($rid -in $script:hiddenRows -or $script:deletedIds.Contains($rid)){return $false}
                if($_.Mode -in '관심 종목','수동 보유','위젯 종목' -and $rid -notin $validLocalIds){return $false}
                return $true
            })
            $script:lastRows=$rows
            $selectedIds=@($grid.SelectedItems | ForEach-Object Id)
            $script:tableRows=@($rows | Where-Object {$_.Mode -notin '시장 지수','연동'} | Where-Object {$_.Id -notlike 'account-*'})
            foreach($item in $script:tableRows){$id=[string]$item.Id;if(!$script:widgetVisibility.ContainsKey($id)){$script:widgetVisibility[$id]=($item.Mode -eq '토스 보유')};$item | Add-Member -NotePropertyName WidgetVisible -NotePropertyValue ([bool]$script:widgetVisibility[$id]) -Force;$item | Add-Member -NotePropertyName WidgetLabel -NotePropertyValue $(if($item.WidgetVisible){'ON'}else{'OFF'}) -Force;$item | Add-Member -NotePropertyName WidgetBrush -NotePropertyValue $(if($item.WidgetVisible){New-Brush '#FF2D7FF9'}else{New-Brush '#FF8993A0'}) -Force;Apply-RowTheme $item;$closed=($item.MarketStatus -eq '장마감');$item | Add-Member -NotePropertyName ClosedStatusVisibility -NotePropertyValue $(if($closed){'Visible'}else{'Collapsed'}) -Force;$item | Add-Member -NotePropertyName BadgeStatusVisibility -NotePropertyValue $(if($closed){'Collapsed'}else{'Visible'}) -Force;$sym=$script:entries | Where-Object Id -eq $id | Select-Object -First 1;$symbolText=if($sym){[string]$sym.Symbol}elseif($item.Mode -eq '토스 보유' -and [string]$item.Name -match '·\s*([^·]+)$'){$Matches[1].Trim()}else{[string]$item.Detail};$displayName=[regex]::Replace([string]$item.Name,'\s·\s[^·]+$','');$item | Add-Member -NotePropertyName DisplayName -NotePropertyValue $displayName -Force;$item | Add-Member -NotePropertyName Symbol -NotePropertyValue $symbolText -Force;$timeText=[string]$item.Stamp;if($item.MarketStatus){$timeText=$timeText -replace ('^'+[regex]::Escape([string]$item.MarketStatus)+'\s*·\s*'),' '};$item | Add-Member -NotePropertyName StatusLine -NotePropertyValue $(if($item.MarketStatus){"$($item.MarketStatus) · $($timeText.Trim())"}else{$timeText}) -Force;$surface=if($item.MarketStatus -eq '정규장'){'#1E20B486'}elseif($item.MarketStatus -like '*프리*'){'#24F0A542'}elseif($item.MarketStatus -like '*애프터*'){'#248585FF'}else{'#1E20B486'};$item | Add-Member -NotePropertyName StatusSurface -NotePropertyValue (New-Brush $surface) -Force}
            Update-TableView
            $tossGrid.ItemsSource=$script:holdingRows
            foreach($row in $rows){if($row.Id -in $selectedIds){[void]$grid.SelectedItems.Add($row)}}
            Sync-Cards $rows
            $script:indexRows=@($script:publicRows | Where-Object {$_.Mode -eq '시장 지수'})
            Set-IndexPage
            $holdingItems=@($script:holdingRows | Where-Object {$_.Id -like 'toss-*'});$linkError=$script:holdingRows | Where-Object {$_.Mode -eq '연동'} | Select-Object -First 1;$emptyAccount=$script:holdingRows | Where-Object {$_.Id -like 'account-*'} | Select-Object -First 1; if(!$script:credential){$script:apiConnectionState='연결 안 됨';$tossStatus.Text='○ API 연결 안 됨 · 설정에서 토스 API를 연결하세요.';$tossStatus.Foreground=New-Brush '#FF9299A1'}elseif($linkError){$script:apiConnectionState='조회 실패';$script:apiConnectionDetail="$($linkError.Name) $($linkError.Detail)";$tossStatus.Text="● 키는 저장됨 · $($script:apiConnectionDetail)";$tossStatus.Foreground=New-Brush '#FFE5484D'}elseif($holdingItems.Count){$script:apiConnectionState='정상 연결';$script:apiConnectionDetail='';$tossStatus.Text="● API 정상 연결 · 보유 종목 $($holdingItems.Count)개 · 60초마다 갱신";$tossStatus.Foreground=New-Brush '#FF20B486'}elseif($emptyAccount){$script:apiConnectionState='정상 연결';$script:apiConnectionDetail='';$tossStatus.Text='● API 정상 연결 · 계좌에 표시할 보유 종목이 없어요.';$tossStatus.Foreground=New-Brush '#FF20B486'}else{$script:apiConnectionState='조회 확인 중';$tossStatus.Text='● 키 저장됨 · 아직 조회 응답을 받지 못했어요. 새로고침을 눌러 주세요.';$tossStatus.Foreground=New-Brush '#FFF0A542'}
            Apply-Theme $window
            $status.Text='지수·환율은 60초마다, 보유 주식은 60초마다 자동 갱신돼요.'
        }catch{$status.Text='조회 실패 · '+$_.Exception.Message;$script:apiConnectionState='조회 실패';$script:apiConnectionDetail=$_.Exception.Message;if($script:credential){$tossStatus.Text='● 키는 저장되어 있지만 조회에 실패했어요 · '+$_.Exception.Message;$tossStatus.Foreground=New-Brush '#FFE5484D'}}
        finally{
            $job.Dispose();$script:job=$null
            if($completedSection -in 'all','public'){$script:nextPublic=[datetime]::Now.AddSeconds(60)}
            if($completedSection -in 'all','holdings'){$script:nextHolding=[datetime]::Now.AddSeconds(60)}
        }
        if($script:queuedSections.Count){$queued=$script:queuedSections[0];$script:queuedSections=@($script:queuedSections | Select-Object -Skip 1);Fetch $queued}
    }elseif(!$job){
        if([datetime]::Now -ge $script:nextPublic){$script:nextPublic=[datetime]::Now.AddSeconds(60);Fetch 'public'}
        elseif($script:credential -and [datetime]::Now -ge $script:nextHolding){$script:nextHolding=[datetime]::Now.AddSeconds(60);Fetch 'holdings'}
    }
})
$results.AddHandler([Windows.Controls.Primitives.ButtonBase]::ClickEvent,[Windows.RoutedEventHandler]{param($sender,$e);$button=$e.OriginalSource;while($button -and -not ($button -is [Windows.Controls.Button])){$button=[Windows.Media.VisualTreeHelper]::GetParent($button)};if($button -and $button.Name -eq 'resultAdd' -and $button.DataContext){Add-Candidate $button.DataContext}}.GetNewClosure(),$true)
$results.Add_PreviewMouseLeftButtonDown({param($o,$e) $script:dragStart=$e.GetPosition($results)})
$results.Add_PreviewMouseMove({param($o,$e)
    if($e.LeftButton -ne 'Pressed' -or !$dragStart -or !$results.SelectedItem){return}
    $point=$e.GetPosition($results)
    if([math]::Abs($point.X-$dragStart.X) -lt 5 -and [math]::Abs($point.Y-$dragStart.Y) -lt 5){return}
    $script:dragStart=$null
    $payload=[Windows.DataObject]::new('StockWidget.Symbol',[string]$results.SelectedItem.Symbol)
    [void][Windows.DragDrop]::DoDragDrop($results,$payload,'Copy')
})
$dropZone.Add_PreviewDragOver({param($o,$e)
    $e.Effects=if($e.Data.GetDataPresent('StockWidget.Symbol')){'Copy'}else{'None'}
    $e.Handled=$true
})
$dropZone.Add_PreviewDrop({param($o,$e)
    $match=$results.ItemsSource | Where-Object Symbol -eq ($e.Data.GetData('StockWidget.Symbol')) | Select-Object -First 1
    if($match){Add-Candidate $match}
    $e.Handled=$true
})
$discovery=Get-Content -Raw (Join-Path $PSScriptRoot 'StockDiscovery.ps1')
$rankCache=@{}
function Queue-Search {
    $script:searchDue=[datetime]::Now.AddMilliseconds(300)
    $results.ItemsSource=$null
    $caption.Text='조회 중…'
}
$symbol.Add_TextChanged({$searchPlaceholder.Visibility=if($symbol.Text.Length){'Collapsed'}else{'Visible'};Queue-Search})
$market.Add_SelectionChanged({Apply-ComboColors $market;Queue-Search})
function Set-CandidateStates($items){foreach($candidate in @($items)){$candidate | Add-Member -NotePropertyName IsAdded -NotePropertyValue ([bool](@($script:entries | Where-Object Symbol -eq $candidate.Symbol).Count)) -Force;$candidate | Add-Member -NotePropertyName SubLine -NotePropertyValue ("$($candidate.Code) · 거래량 $($candidate.Volume)") -Force}}
$poll=[Windows.Threading.DispatcherTimer]::new()
$poll.Interval=[timespan]::FromMilliseconds(150)
$poll.Add_Tick({
    $query=$symbol.Text.Trim()
    $index=$market.SelectedIndex
    $key="$index/$query"
    if($lookup -and $lookupTask.IsCompleted){
        try{
            $matchesFound=@($lookup.EndInvoke($lookupTask))
            if(!$lookupQuery -and $matchesFound.Count){$rankCache[$lookupKey]=@{time=[datetime]::Now;rows=$matchesFound}}
            if($lookupKey -eq $key){
                Set-CandidateStates $matchesFound;$results.ItemsSource=$matchesFound
                $results.SelectedIndex=0
                $caption.Text=if(!$matchesFound.Count -and $query){'검색 결과가 없어요 · 종목명이나 티커를 확인하세요'}elseif(!$matchesFound.Count){'표시할 종목이 없어요'}elseif($query){'이름·코드 검색 결과'}else{'거래량 상위 30'}
            }
        }catch{if($lookupKey -eq $key){$caption.Text="네이버 금융 검색에 실패했어요 · 네트워크를 확인하고 다시 시도하세요"}}
        finally{$lookup.Dispose();$script:lookup=$null}
    }
    if($lookup -or !$searchDue -or [datetime]::Now -lt $searchDue){return}
    $script:searchDue=$null
    if(!$query -and $rankCache[$key] -and $rankCache[$key].time -gt [datetime]::Now.AddMinutes(-5)){
        Set-CandidateStates $rankCache[$key].rows;$results.ItemsSource=$rankCache[$key].rows
        $results.SelectedIndex=0
        $caption.Text='거래량 상위 30'
        return
    }
    $script:lookupKey=$key
    $script:lookupQuery=$query
    $script:lookup=[powershell]::Create()
    [void]$lookup.AddScript($discovery).AddArgument($query).AddArgument($index)
    $script:lookupTask=$lookup.BeginInvoke()
})
$update.Add_Click({$rankCache.Clear();Queue-Search})
$window.Add_Closed({Save-Preferences;$poll.Stop();foreach($key in @($cards.Keys)){$cards[$key].Close()};if($lookup){$lookup.Stop();$lookup.Dispose()}})
$searchPlaceholder.Visibility=if($symbol.Text.Length){'Collapsed'}else{'Visible'}
Queue-Search
if($Check){
    $source=Get-Content -Raw $PSCommandPath
    $popupMatch=[regex]::Match($source,'\$panel=WindowFrom @"\r?\n(?<xaml>.*?)\r?\n"@',[Text.RegularExpressions.RegexOptions]::Singleline)
    if(!$popupMatch.Success){throw '위젯 화면 정의를 찾을 수 없습니다.'}
    [void](WindowFrom $popupMatch.Groups['xaml'].Value)
    $settingsMatch=[regex]::Match($source,'\$dialog=WindowFrom @"\r?\n(?<xaml>.*?)\r?\n"@',[Text.RegularExpressions.RegexOptions]::Singleline)
    if(!$settingsMatch.Success){throw '설정 화면 정의를 찾을 수 없습니다.'}
    [void](WindowFrom $settingsMatch.Groups['xaml'].Value)
    $space.Dispose()
    return
}
$poll.Start()
$indexTimer.Start()
if($script:credential){$script:queuedSections=@('public');Fetch 'holdings'}else{Fetch 'public'}
$timer.Start()
try{[void]$window.ShowDialog()}catch{[Windows.MessageBox]::Show($_.Exception.ToString(), 'StockWidget 시작 오류', 'OK', 'Error') | Out-Null}finally{$timer.Stop();if($job){$job.Stop();$job.Dispose()};$space.Dispose()}
