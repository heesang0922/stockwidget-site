﻿param([string]$query,[int]$marketIndex)
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
function Get-Feed($url){
    Invoke-RestMethod $url -UserAgent 'Mozilla/5.0' -TimeoutSec 8
}
function PriceText($raw,$currency){
    $number=0d
    if($null -eq $raw -or [string]::IsNullOrWhiteSpace([string]$raw)){return '—'}
    if([decimal]::TryParse([string]$raw,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$number)){'{0:#,##0.####} {1}' -f $number,$currency}else{"$raw $currency"}
}
function Candidate($name,$code,$market,$volume,$rank,$price='—'){
    $symbol=switch($market){'코스피'{"$code.KS"} '코스닥'{"$code.KQ"} default{$code.Replace('.','-')}}
    [pscustomobject]@{Name=$name;Code=$code;Market=$market;Symbol=$symbol;Volume=$volume;Rank=$rank;Price=$price}
}
function Add-Quote($candidate){
    try{
        $m=(Get-Feed "https://query1.finance.yahoo.com/v8/finance/chart/$($candidate.Symbol)?interval=1m&range=1d").chart.result[0].meta
        $price=$m.regularMarketPrice
        if($m.marketState -eq 'PRE' -and $m.preMarketPrice){$price=$m.preMarketPrice}elseif($m.marketState -eq 'POST' -and $m.postMarketPrice){$price=$m.postMarketPrice}
        $candidate.Price=PriceText $price $m.currency
    }catch{$candidate.Price='—'}
    $candidate
}
if($query){
    $encoded=[uri]::EscapeDataString($query)
    $found=Get-Feed "https://ac.stock.naver.com/ac?q=$encoded&target=stock"
    foreach($i in ($found.items | Select-Object -First 10)){
        $market=if($i.typeCode -eq 'KOSPI'){'코스피'}elseif($i.typeCode -eq 'KOSDAQ'){'코스닥'}elseif($i.nationCode -eq 'USA'){'미국'}else{continue}
        Add-Quote (Candidate $i.name $i.code $market '' '')
    }
    return
}
if($marketIndex -eq 2){
    $feed=Get-Feed 'https://query1.finance.yahoo.com/v1/finance/screener/predefined/saved?scrIds=most_actives&count=30'
    $rank=0
    foreach($i in $feed.finance.result[0].quotes){
        Candidate $i.shortName $i.symbol '미국' ('{0:N0}' -f $i.regularMarketVolume) (++$rank) (PriceText $i.regularMarketPrice $i.currency)
    }
    return
}
$exchange=@('KOSPI','KOSDAQ')[$marketIndex]
$label=@('코스피','코스닥')[$marketIndex]
$stocks=for($page=1;;$page++){
    $feed=Get-Feed "https://m.stock.naver.com/api/stocks/marketValue/${exchange}?page=$page&pageSize=100"
    if(!$feed.stocks){break}
    $feed.stocks
    if($page*100 -ge $feed.totalCount){break}
}
$rank=0
$stocks | Sort-Object {[long]$_.accumulatedTradingVolumeRaw} -Descending | Select-Object -First 30 | ForEach-Object {
    $rawPrice=if($_.closePriceRaw){$_.closePriceRaw}else{$_.closePrice}
    Candidate $_.stockName $_.itemCode $label $_.accumulatedTradingVolume (++$rank) (PriceText $rawPrice 'KRW')
}
