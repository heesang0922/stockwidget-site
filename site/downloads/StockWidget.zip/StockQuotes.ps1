﻿param($entries,$credential,$section='all')
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Rate($value) {
    if ($null -eq $value) { return '—' }
    '{0:+0.00%;-0.00%;0.00%}' -f [decimal]$value
}
function Money($value,$currency) {
    if ($null -eq $value) { return '—' }
    '{0:#,##0.####} {1}' -f [decimal]$value,$currency
}
function GainMoney($value,$currency) {
    if ($null -eq $value) { return '—' }
    '{0:+#,##0.####;-#,##0.####;0} {1}' -f [decimal]$value,$currency
}
function MarketStatus($state,$currency) {
    $state=([string]$state).ToUpperInvariant()
    if($currency -eq 'KRW'){
        $now=[TimeZoneInfo]::ConvertTimeFromUtc([datetime]::UtcNow,[TimeZoneInfo]::FindSystemTimeZoneById('Korea Standard Time'))
        if($now.DayOfWeek -in 'Saturday','Sunday'){return '장마감'}
        $at=$now.TimeOfDay
        if($at -ge [timespan]::FromHours(9) -and $at -lt [timespan]::FromHours(15.5)){return '정규장'}
        if($at -ge [timespan]::FromHours(15.6667) -and $at -lt [timespan]::FromHours(18)){return '시간외거래'}
        return '장마감'
    }
    if($state -eq 'PRE'){return '프리마켓'}
    if($state -in 'POST','POSTPOST'){return '애프터마켓'}
    if($state -eq 'PREPRE'){return '주간거래'}
    if($state -eq 'REGULAR'){return '정규장'}
    if($state -eq 'CLOSED'){return '장마감'}
    if($currency -eq 'USD'){
        $tz=[TimeZoneInfo]::FindSystemTimeZoneById('Eastern Standard Time')
        $now=[TimeZoneInfo]::ConvertTimeFromUtc([datetime]::UtcNow,$tz)
        if($now.DayOfWeek -in 'Saturday','Sunday'){return '장마감'}
        $at=$now.TimeOfDay
        if($at -ge [timespan]::FromHours(9.5) -and $at -lt [timespan]::FromHours(16)){return '정규장'}
        if($at -ge [timespan]::FromHours(4) -and $at -lt [timespan]::FromHours(9.5)){return '프리마켓'}
        if($at -ge [timespan]::FromHours(16) -and $at -lt [timespan]::FromHours(20)){return '애프터마켓'}
        return '장마감'
    }
    ''
}
function Row($id,$name,$mode,$price,$day,$gain,$detail,$stamp,$delta='',$sparkline=$null,$marketStatus='',$gainLabel='',$pnl='') {
    $dayBrush=if($day -match '^\s*[-−]'){'#3A9BFF'}elseif($day -match '^\s*\+'){'#FF4967'}else{'#9299A1'}
    $gainBrush=if($gain -match '^\s*[-−]'){'#3A9BFF'}elseif($gain -match '^\s*\+'){'#FF4967'}else{'#9299A1'}
    $gainSurface=if($gain -match '^\s*[-−]'){'#243A9BFF'}elseif($gain -match '^\s*\+'){'#24FF4967'}else{'#1A9299A1'}
    $gainDisplay=$gain
    $gainCard=if($gainLabel){$gainDisplay}else{''}
    $marketBrush=switch($marketStatus){'정규장'{'#20B486'}'실시간'{'#20B486'}'프리마켓'{'#F0A542'}'애프터마켓'{'#F0A542'}'주간거래'{'#F0A542'}'시간외거래'{'#F0A542'}'장마감'{'#9299A1'}default{'#9299A1'}}
    $marketSurface=switch($marketStatus){'정규장'{'#1420B486'}'실시간'{'#1420B486'}'프리마켓'{'#24F0A542'}'애프터마켓'{'#24F0A542'}'주간거래'{'#24F0A542'}'시간외거래'{'#24F0A542'}'장마감'{'#1A9299A1'}default{'#1A9299A1'}}
    [pscustomobject]@{Id=$id;Name=$name;Mode=$mode;Price=$price;Day=$day;Gain=$gain;GainDisplay=$gainDisplay;GainPnl=$pnl;GainLabel=$gainLabel;GainCard=$gainCard;GainVisibility=$(if($gainLabel){'Visible'}else{'Collapsed'});GainSurface=$gainSurface;Detail=$detail;Stamp=$stamp;Delta=$delta;DayBrush=$dayBrush;GainBrush=$gainBrush;Sparkline=$sparkline;MarketStatus=$marketStatus;MarketBrush=$marketBrush;MarketSurface=$marketSurface}
}
if($section -ne 'holdings'){
$cache=@{}
foreach ($entry in $entries) {
    $sym=$entry.Symbol
    try {
        if (!$cache.ContainsKey($sym)) {
            $encodedSymbol=[uri]::EscapeDataString([string]$sym)
            $url="https://query1.finance.yahoo.com/v8/finance/chart/${encodedSymbol}?interval=5m&range=1d"
            $response=Invoke-RestMethod -Uri $url -UserAgent 'Mozilla/5.0' -TimeoutSec 8 -ErrorAction Stop
            $result=$response.chart.result | Select-Object -First 1
            if(!$result -or !$result.meta){throw 'Yahoo Finance 응답에 시세 정보가 없습니다.'}
            $quote=$result.indicators.quote | Select-Object -First 1
            $cache[$sym]=@{Meta=$result.meta;Closes=@($quote.close);Timestamps=@($result.timestamp)}
        }
        $m=$cache[$sym].Meta
        $latestClose=@($cache[$sym].Closes | Where-Object {$null -ne $_} | Select-Object -Last 1)
        $rawPrice=$m.regularMarketPrice
        if($null -eq $rawPrice -and $latestClose.Count){$rawPrice=$latestClose[0]}
        if ($null -eq $rawPrice -or [string]::IsNullOrWhiteSpace([string]$rawPrice)) { throw 'Yahoo Finance 응답에 현재가가 없습니다.' }
        $price=[decimal]$rawPrice
        if($m.marketState -eq 'PRE' -and $m.preMarketPrice){$price=[decimal]$m.preMarketPrice}
        elseif($m.marketState -eq 'POST' -and $m.postMarketPrice){$price=[decimal]$m.postMarketPrice}
        $changeAmount=if($m.chartPreviousClose -gt 0){$price-[decimal]$m.chartPreviousClose}else{$null}
        $change=if ($m.chartPreviousClose -gt 0) { $changeAmount/[decimal]$m.chartPreviousClose }
        $gain='—'
        $detail=$sym
        if ($entry.Mode -eq '수동 보유') {
            $gain=Rate (($price/[decimal]$entry.Cost)-1)
            $pnl=Money (($price-[decimal]$entry.Cost)*[decimal]$entry.Qty) $m.currency
            $detail="$($entry.Qty)주 · 평단 $(Money $entry.Cost $m.currency) · 평가손익 $pnl"
        }
        $marketStatus=MarketStatus $m.marketState $m.currency
        $marketTimestamp=$m.regularMarketTime
        if(!$marketTimestamp -and $cache[$sym].Timestamps.Count){$marketTimestamp=$cache[$sym].Timestamps[-1]}
        if($m.marketState -eq 'PRE' -and $m.preMarketTime){$marketTimestamp=$m.preMarketTime}
        elseif($m.marketState -eq 'POST' -and $m.postMarketTime){$marketTimestamp=$m.postMarketTime}
        $stampTime=[datetimeoffset]::FromUnixTimeSeconds($marketTimestamp).LocalDateTime.ToString('MM-dd HH:mm')
        $stamp=if($marketStatus){"$marketStatus · $stampTime"}else{$stampTime}
        $label=if($entry.Name){$entry.Name}else{$m.shortName}
        $amount=if($null -ne $changeAmount){'{0:+#,##0.####;-#,##0.####;0}' -f [decimal]$changeAmount}else{''}
        $percent=if($null -ne $change){Rate $change}else{''}
        $delta=if($amount){"$amount ($percent)"}else{$percent}
        # A chart rendering/data issue must not discard a valid price for this symbol.
        $points=$null
        try {
            $valid=@($cache[$sym].Closes | Where-Object {$null -ne $_})
            if($valid.Count -gt 1){
                $values=@($valid | ForEach-Object {[double]$_});$min=($values|Measure-Object -Minimum).Minimum;$max=($values|Measure-Object -Maximum).Maximum;$range=$max-$min
                $points=[Windows.Media.PointCollection]::new()
                for($i=0;$i -lt $values.Count;$i++){$x=150*$i/($values.Count-1);$y=32-($(if($range -eq 0){0.5}else{($values[$i]-$min)/$range})*28);$points.Add([Windows.Point]::new($x,$y))}
                $points.Freeze()
            }
        } catch { $points=$null }
        $gainLabel=if($entry.Mode -eq '수동 보유'){'매입 손익'}else{''}
        $gainPnl=if($entry.Mode -eq '수동 보유'){Money (($price-[decimal]$entry.Cost)*[decimal]$entry.Qty) $m.currency}else{''}
        Row $entry.Id "$label · $sym" $entry.Mode (Money $price $m.currency) $delta $gain $detail $stamp $delta $points $marketStatus $gainLabel $gainPnl
    } catch { Row $entry.Id $sym $entry.Mode '조회 실패' '—' '—' $_.Exception.Message '—' }
}
$indices=@(@{Id='index-fx';Symbol='KRW=X';Name='달러 환율'},@{Id='index-kospi';Symbol='^KS11';Name='코스피'},@{Id='index-kosdaq';Symbol='^KQ11';Name='코스닥'},@{Id='index-nasdaq-futures';Symbol='NQ=F';Name='나스닥 100 선물'},@{Id='index-nasdaq';Symbol='^IXIC';Name='나스닥'},@{Id='index-sp500';Symbol='^GSPC';Name='S&P 500'},@{Id='index-dow';Symbol='^DJI';Name='다우존스'},@{Id='index-vix';Symbol='^VIX';Name='VIX'},@{Id='index-russell-futures';Symbol='RTY=F';Name='러셀 2000 선물'},@{Id='index-phlx-semi';Symbol='^SOX';Name='필라델피아 반도체'})
foreach($index in $indices){try{
    $interval=if($index.Id -eq 'index-fx'){'1m'}else{'1d'}
    $url="https://query1.finance.yahoo.com/v8/finance/chart/$([uri]::EscapeDataString($index.Symbol))?interval=$interval&range=1d"
    $meta=(Invoke-RestMethod $url -UserAgent 'Mozilla/5.0' -TimeoutSec 8).chart.result[0].meta
    if(!$meta.regularMarketPrice){throw '시세 없음'}
    $change=[decimal]$meta.regularMarketPrice-[decimal]$meta.chartPreviousClose
    $rate=if($meta.chartPreviousClose -gt 0){$change/[decimal]$meta.chartPreviousClose}else{0}
    $amount='{0:+#,##0.##;-#,##0.##;0}' -f $change
    $indexPrice='{0:#,##0.##}' -f [decimal]$meta.regularMarketPrice
    $marketStatus=if($index.Id -eq 'index-fx'){'실시간'}else{MarketStatus $meta.marketState $meta.currency}
    $stamp=if($marketStatus){"$marketStatus · $(Get-Date -Format 'HH:mm')"}else{"$(Get-Date -Format 'HH:mm')"}
    Row $index.Id $index.Name '시장 지수' $indexPrice (Rate $rate) '—' $index.Symbol $stamp "$amount ($(Rate $rate))" $null $marketStatus
}catch{Row $index.Id $index.Name '시장 지수' '조회 실패' '—' '—' $index.Symbol '—' '시세를 불러오지 못했어요'}}
}
if($section -eq 'public'){return}
if (!$credential) { return }
$base='https://openapi.tossinvest.com'
try {
    $stage='인증'
    if (!$script:token -or $script:expires -le [datetime]::UtcNow) {
        $form=@{grant_type='client_credentials';client_id=$credential.UserName.Trim();client_secret=$credential.GetNetworkCredential().Password.Trim()}
        $auth=Invoke-RestMethod "$base/oauth2/token" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body $form -TimeoutSec 10
        if(!$auth.access_token){throw '인증 응답 누락'}
        $script:token=$auth.access_token
        $script:expires=[datetime]::UtcNow.AddSeconds([math]::Max(0,$auth.expires_in-60))
    }
    $headers=@{Authorization="Bearer $script:token"}
    $stage='계좌 목록 조회'
    $accounts=(Invoke-RestMethod "$base/api/v1/accounts" -Headers $headers -TimeoutSec 10).result
    if ($null -eq $accounts){throw '계좌 응답 누락'}
    if (!$accounts) { Row 'status' '토스증권' '연동' '계좌 없음' '—' '—' '' '—' }
    foreach ($acct in $accounts) {
        $headers['X-Tossinvest-Account']=[string]$acct.accountSeq
        $stage='보유 종목 조회'
        $items=(Invoke-RestMethod "$base/api/v1/holdings" -Headers $headers -TimeoutSec 10).result.items
        if ($null -eq $items){throw '보유 목록 누락'}
        if (!$items) { Row "account-$($acct.accountSeq)" '토스 보유 종목' '토스 보유' '—' '—' '—' '계좌에 보유 종목이 없습니다. 종목이 생기면 이 위젯에 표시됩니다.' '—' }
        foreach ($h in $items) {
            $quantity=[decimal]$h.quantity
            $price=[decimal]$h.lastPrice
            $average=[decimal]$h.averagePurchasePrice
            $profit=$h.profitLoss.amount
            if($null -eq $profit -and $average -gt 0){$profit=($price-$average)*$quantity}
            $profitRate=$h.profitLoss.rate
            if($null -eq $profitRate -and $average -gt 0){$profitRate=($price/$average)-1}
            $dayRate=$h.dailyProfitLoss.rate
            $dayAmount=$h.dailyProfitLoss.amount
            if($null -eq $dayAmount -and $null -ne $dayRate -and [decimal]$dayRate -ne -1){$dayAmount=$price*$quantity*([decimal]$dayRate/(1+[decimal]$dayRate))}
            $deltaAmount=if($null -ne $dayAmount){'{0:+#,##0.####;-#,##0.####;0}' -f [decimal]$dayAmount}else{''}
            $percent=Rate $dayRate
            $delta=if($deltaAmount){"$deltaAmount ($percent)"}else{$percent}
            $marketStatus=MarketStatus $h.marketState $h.currency
            $detail="$($h.quantity)주 보유 · 평단 $(Money $average $h.currency) · 매입 손익 $(Money $profit $h.currency)"
            $stampTime=Get-Date -Format 'MM-dd HH:mm'
            $stamp=if($marketStatus){"$marketStatus · $stampTime"}else{$stampTime}
            $points=$null
            try {
                $chartSymbol=[string]$h.symbol
                if($h.currency -eq 'KRW' -and $chartSymbol -match '^\d{6}$'){$chartSymbol+='.KS'}
                $chartUrl="https://query1.finance.yahoo.com/v8/finance/chart/$([uri]::EscapeDataString($chartSymbol))?interval=5m&range=1d"
                $chart=(Invoke-RestMethod $chartUrl -UserAgent 'Mozilla/5.0' -TimeoutSec 5).chart.result[0]
                $values=@($chart.indicators.quote[0].close | Where-Object {$null -ne $_} | ForEach-Object {[double]$_})
                if($values.Count -gt 1){
                    $min=($values|Measure-Object -Minimum).Minimum;$max=($values|Measure-Object -Maximum).Maximum;$range=$max-$min
                    $points=[Windows.Media.PointCollection]::new()
                    for($i=0;$i -lt $values.Count;$i++){$x=150*$i/($values.Count-1);$y=32-($(if($range -eq 0){0.5}else{($values[$i]-$min)/$range})*28);$points.Add([Windows.Point]::new($x,$y))}
                    $points.Freeze()
                }
            } catch { $points=$null }
            Row "toss-$($acct.accountSeq)-$($h.symbol)" "$($h.name) · $($h.symbol)" '토스 보유' (Money $price $h.currency) $delta (Rate $profitRate) $detail $stamp $delta $points $marketStatus '평가 손익' (GainMoney $profit $h.currency)
        }
    }
} catch {
    $script:token=$null
    $http=[int]$_.Exception.Response.StatusCode
    $reason=switch($http){401{'토큰 발급 거부 · Client ID와 Secret 짝 확인'} 403{if($stage -eq '인증'){'허용 IP 미등록 가능성 (403)'}else{'계좌 조회 권한 또는 허용 IP 확인 (403)'}} 429{'요청 한도 초과'} 0{'네트워크 또는 응답 형식 확인'} default{"HTTP $http"}}
    $apiCode='';$apiMessage=''
    if($_.ErrorDetails.Message){try{$body=$_.ErrorDetails.Message | ConvertFrom-Json;$apiCode=[string]$body.error.code;$apiMessage=[string]$body.error.message;if(!$apiCode){$apiCode=[string]$body.code};if(!$apiMessage){$apiMessage=[string]$body.message}}catch{$apiMessage=$_.Exception.Message}}
    if(!$apiMessage -and $http -eq 0){$apiMessage=$_.Exception.Message}
    $detail=if($apiCode -and $apiMessage){"오류 코드: $apiCode · $apiMessage"}elseif($apiCode){"오류 코드: $apiCode"}elseif($apiMessage){$apiMessage}else{switch($http){401{'토스가 Client ID/Secret 조합을 거부했습니다. 발급된 한 쌍과 활성 상태를 확인하세요.'}403{'토스 WTS에서 현재 인터넷 IP가 Open API 허용 목록에 등록됐는지 확인하세요.'}default{'토스 API 응답과 계좌 조회 권한을 확인하세요.'}}}
    Row 'status' "토스 $stage 실패 · $reason" '연동' '—' '—' '—' $detail '—'
}
